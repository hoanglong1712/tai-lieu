$HADOOP_HOME/bin/hadoop jar Grep.jar Grep [a-z\s]+ $1 /user/output/

