$HADOOP_HOME/bin/hadoop fs -rm /user/output/*
$HADOOP_HOME/bin/hadoop fs -rmdir /user/output
$HADOOP_HOME/bin/hadoop fs -ls /user
