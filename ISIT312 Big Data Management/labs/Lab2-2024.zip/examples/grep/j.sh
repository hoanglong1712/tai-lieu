jar cf Grep.jar Grep*.class

