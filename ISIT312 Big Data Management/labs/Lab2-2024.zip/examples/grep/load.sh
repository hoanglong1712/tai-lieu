$HADOOP_HOME/bin/hadoop fs -put $1 .
