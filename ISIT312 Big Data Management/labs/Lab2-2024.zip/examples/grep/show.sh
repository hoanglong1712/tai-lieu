$HADOOP_HOME/bin/hadoop fs -cat /user/output/part*

