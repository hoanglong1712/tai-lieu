#!/bin/bash
# Dựng toàn bộ bản dịch.
#   bash build.sh          -> output/XuLyNgonNguTuNhien_BanDichTiengViet.pdf (bản khổ lớn, cả cuốn)
#   bash build.sh mobile   -> output/dien_thoai/*.pdf (khổ điện thoại, mỗi chương một file)
#   bash build.sh all      -> cả hai
set -e
cd "$(dirname "$0")"
ROOT=$(pwd); mkdir -p output build
MODE=${1:-full}

full() {
  echo ">> Bản khổ lớn (3 lượt xelatex + sinh bảng thuật ngữ)..."
  cd "$ROOT/build"
  for i in 1 2; do TEXINPUTS="$ROOT": xelatex -interaction=nonstopmode "$ROOT/main.tex" > xelatex_$i.log 2>&1 || true; done
  python3 "$ROOT/tools/make_glossary.py"
  TEXINPUTS="$ROOT": xelatex -interaction=nonstopmode "$ROOT/main.tex" > xelatex_3.log 2>&1 || true
  TEXINPUTS="$ROOT": xelatex -interaction=nonstopmode "$ROOT/main.tex" > xelatex_4.log 2>&1 || true
  echo "   Lỗi LaTeX: $(grep -c '^!' main.log)"; cp main.pdf "$ROOT/output/XuLyNgonNguTuNhien_BanDichTiengViet.pdf"
  cd "$ROOT"
}

mobile() {
  echo ">> Bản điện thoại..."
  [ -f "$ROOT/chapters/z_glossary.tex" ] || { echo "Chưa có chapters/z_glossary.tex: chạy 'bash build.sh' trước."; exit 1; }
  cat mobile/jobs.txt | xargs -P "${JOBS:-4}" -L 1 bash mobile/mk.sh
  bash mobile/mkfront.sh
  O="$ROOT/output/dien_thoai"; mkdir -p "$O"
  names=("" "NenTangHocMay" "NenTangMangNoRon" "TuVaVectoTu" "MoHinhChuoiHoiQuyVaTichChap" "MoHinhChuoiSangChuoi" "Transformer" "TienHuanLuyen" "MoHinhSinh" "Prompting" "CanChinh" "SuyLuan" "LapLuan")
  cp mobile/Front.pdf "$O/00_LoiNoiDau_HuongDanDoc.pdf"
  for i in $(seq 1 12); do n=$(printf %02d $i); cp mobile/Chuong$n.pdf "$O/Chuong${n}_${names[$i]}.pdf"; done
  cp mobile/Gloss.pdf "$O/13_BangThuatNgu_AnhViet.pdf"
  if command -v qpdf >/dev/null; then qpdf orig.pdf --pages orig.pdf 663-745 -- "$O/14_TaiLieuThamKhao_ChiMuc_NguyenBan.pdf"; fi
}

case "$MODE" in full) full;; mobile) mobile;; all) full; mobile;; *) echo "Dùng: bash build.sh [full|mobile|all]"; exit 1;; esac
echo ">> Xong. Kết quả trong thư mục output/"
