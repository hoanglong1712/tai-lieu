# Mã nguồn LaTeX — Bản dịch tiếng Việt có chú giải

*Natural Language Processing: Neural Networks and Large Language Models* — Tong Xiao & Jingbo Zhu
(nguyên tác © 2021–2026, giấy phép **CC BY-NC 4.0**, https://github.com/NiuTrans/NLPBook).
Bản dịch tiếng Việt không chính thức, phi thương mại; được chia sẻ theo cùng giấy phép CC BY-NC 4.0.

## Biên dịch nhanh

```bash
bash build.sh          # bản khổ lớn (cả cuốn)      -> output/XuLyNgonNguTuNhien_BanDichTiengViet.pdf
bash build.sh mobile   # khổ điện thoại, từng chương -> output/dien_thoai/*.pdf  (cần chạy build.sh trước 1 lần)
bash build.sh all      # cả hai
JOBS=6 bash build.sh mobile   # biên dịch song song 6 chương
```
Thời gian: bản khổ lớn khoảng 5–10 phút (4 lượt xelatex), bản điện thoại khoảng 3–5 phút với 4 luồng.

## Yêu cầu
- **XeLaTeX** (TeX Live 2022 trở lên; khuyên dùng bản đầy đủ `texlive-full`). Các gói dùng: polyglossia, fontspec,
  amsmath/amssymb/mathtools/bm, tcolorbox, pdfpages, adjustbox, booktabs, multirow, tabularx, longtable, makecell,
  algorithm/algpseudocode, titlesec, fancyhdr, caption/subcaption, needspace, hyperref, expl3.
- **Phông chữ**: TeX Gyre Termes, TeX Gyre Heros (có sẵn trong TeX Live), DejaVu Sans Mono,
  **Noto Serif CJK SC** (cho các ví dụ chữ Hán; Ubuntu/Debian: `sudo apt install fonts-noto-cjk`).
- **Python 3** (sinh bảng thuật ngữ; `figbox.py` cần thêm Pillow và poppler-utils).
- `qpdf` (không bắt buộc, chỉ để tách phần Tài liệu tham khảo/Chỉ mục cho bản điện thoại).
- Trên Overleaf: tải cả thư mục lên, chọn Compiler = **XeLaTeX**, Main document = `main.tex`
  (bảng thuật ngữ `chapters/z_glossary.tex` đã được sinh sẵn nên không cần chạy Python).

## Cấu trúc
| Đường dẫn | Nội dung |
|---|---|
| `main.tex` | File chính của bản khổ lớn (ghép mọi phần, mục lục, thuật ngữ, tài liệu tham khảo) |
| `preamble.tex` | Preamble khổ lớn: phông, tiếng Việt, macro `\tn`, `\tnb` (thuật ngữ), môi trường `chuthich` (chú giải), `hopvd` (hộp ví dụ), `\hinhgoc` (chèn hình vector từ PDF gốc)… |
| `preamble_mobile.tex` | Giống trên nhưng khổ giấy 112×190 mm cho điện thoại |
| `chapters/c00_front.tex`, `c00_preface.tex` | Trang bìa, giấy phép, Lời nói đầu, Hướng dẫn đọc |
| `chapters/cNN_x.tex` | Nội dung dịch: 31 phần, chương NN, phần a/b/c/d (ví dụ `c06_a.tex` = đầu Chương 6) |
| `chapters/z_glossary.tex` | Bảng thuật ngữ Anh–Việt (sinh tự động bởi `tools/make_glossary.py`) |
| `orig.pdf` | Sách gốc — **bắt buộc**: các hình vẽ được chèn trực tiếp (vector) từ file này, Tài liệu tham khảo và Chỉ mục cũng lấy từ đây |
| `mobile/` | Script dựng bản điện thoại (`mk.sh`, `mkfront.sh`, `jobs.txt` = danh sách phần của từng chương) |
| `glossary.md`, `thuat_ngu/terms_*.md` | Bảng thuật ngữ chuẩn và thuật ngữ bổ sung từng phần |
| `tools/` | `make_glossary.py`, `figbox.py` (tìm khung hình trong PDF gốc), `test_chunk.sh` (biên dịch thử 1 phần), quy ước dịch `TRANSLATOR_GUIDE.md`, `style_sample.tex`, `chunks.txt` (phạm vi trang của từng phần) |

## Sửa bản dịch
- Sửa trực tiếp file `chapters/cNN_x.tex`, rồi chạy lại `bash build.sh`.
- Biên dịch thử riêng một phần: `CH=6 SEC=2 bash tools/test_chunk.sh chapters/c06_b.tex`
  (CH/SEC/SUB = số chương/mục/tiểu mục đã qua, để số mục khớp sách gốc; xem cột cuối `tools/chunks.txt`).
- Số phương trình dùng `\tag{x.y}` cố định theo sách gốc; tham chiếu chéo viết số trực tiếp (không dùng `\ref`).
- Thêm thuật ngữ: dùng `\tn{tiếng Việt}{English}`; bảng thuật ngữ cuối sách tự cập nhật khi chạy `build.sh`.
- Chèn hình từ sách gốc: `python3 tools/figbox.py <trang> "Figure 2.4"` → in ra khung, dùng `\hinhgoc{<trang>}{x0 y0 x1 y1}`.
