# Hướng dẫn cho người dịch một phần sách (đọc kỹ toàn bộ trước khi bắt đầu)

Dự án: dịch sang tiếng Việt cuốn *Natural Language Processing: Neural Networks and Large Language Models* (Tong Xiao & Jingbo Zhu),
giấy phép CC BY-NC 4.0 (tác giả cho phép dịch phi thương mại, có ghi nguồn). Bạn đọc mục tiêu: **người vừa học xong THPT ở Việt Nam**.
Thư mục làm việc: `BOOK=/tmp/claude-0/-home-claude/188a7b61-29c4-5f07-94a8-15eb59ead28c/scratchpad/book`

Các file có sẵn trong BOOK:
- `orig.pdf` — sách gốc. Số trang in trên sách = số trang PDF (trang 18 của sách là trang 18 của PDF).
- `preamble.tex` — preamble chung (KHÔNG sửa). Đọc nó để biết các macro.
- `style_sample.tex` — bản mẫu văn phong và cách dùng macro. ĐỌC TRƯỚC.
- `glossary.md` — bảng thuật ngữ chuẩn. BẮT BUỘC theo.
- `figbox.py` — công cụ tìm khung hình để chèn hình vector từ PDF gốc.
- `test_chunk.sh` — biên dịch thử file của bạn.

## Nhiệm vụ
Dịch **đầy đủ, trung thành, không bỏ sót** (mọi đoạn văn, công thức, chú thích chân trang, ví dụ, bảng, thuật toán, hộp văn bản) phạm vi trang
được giao, viết thành MỘT file LaTeX `BOOK/chapters/<id>.tex` (chỉ phần thân, không có \documentclass/\begin{document}),
và bổ sung **chú giải của người dịch** cho người mới học xong THPT.

## Đọc nguồn
1. Lấy văn bản: `pdftotext -f A -l B -layout BOOK/orig.pdf -` (chia nhỏ từng 3–5 trang để không tràn ngữ cảnh).
2. Công thức toán trong pdftotext bị vỡ → PHẢI xem ảnh trang bằng công cụ Read với tham số `pages` (ví dụ `pages: "18-22"`, tối đa ~5 trang/lần để tiết kiệm)
   để chép lại công thức LaTeX chính xác (ký hiệu đậm \mathbf, chỉ số, mũ, dấu ngoặc...). Không bịa công thức.
3. Làm việc tuần tự theo từng cụm 3–5 trang: đọc → viết phần dịch tương ứng (ghi nối vào file bằng Write lần đầu, sau đó dùng Bash `cat >> file <<'EOF'` hoặc Edit để nối tiếp). Không giữ cả phần trong đầu rồi mới viết.

## Quy ước dịch
- Văn phong: tiếng Việt khoa học, tự nhiên, mạch lạc, câu rõ ràng; không dịch word-by-word. Giữ "chúng ta/ta" như sách giáo khoa.
- Thuật ngữ: theo `glossary.md`. Lần đầu xuất hiện trong phần của bạn: `\tn{tiếng Việt}{English}`; nếu sách gốc in đậm: `\tnb{tiếng Việt}{English}`.
  Lần sau chỉ tiếng Việt. Thuật ngữ mới không có trong glossary → tự chọn bản dịch phổ biến và ghi vào `BOOK/terms_<id>.md` (dòng `English | Việt`).
- Tên riêng mô hình/hệ thống (BERT, GPT-4, LLaMA, Word2Vec, PyTorch...) giữ nguyên. Trích dẫn tài liệu giữ dạng văn bản thuần như gốc:
  `Vaswani et al. [2017]` → `Vaswani và cộng sự [2017]`; `[Devlin et al., 2019]` → `[Devlin và cộng sự, 2019]`.
- Tham chiếu chéo: viết số cứng: "Phương trình~(2.13)", "Phương trình~(2.10--2.11)", "Hình~2.4", "Bảng~3.1", "Mục~1.2", "Chương~5", "Thuật toán~5.1".
  KHÔNG dùng \label/\ref/\eqref/\cite.
- Tiêu đề: `\chapter{...}` (chỉ khi phần của bạn bắt đầu chương), `\section{...}`, `\subsection{...}` — dịch tiêu đề, KHÔNG ghi số (LaTeX tự đánh số khớp với gốc).
  Tiêu đề in đậm không số kiểu "1. Vectors and Matrices" → `\tieumuc{1. Vectơ và ma trận}`. Tiêu đề cấp nhỏ hơn không số → `\tieumuc{...}`.
  Trích dẫn đầu chương → `\trichdan{nội dung dịch}{Tên [năm]}`.
- Phương trình: **mỗi phương trình có số đều dùng `\tag{x.y}` đúng số gốc**. Không số → `\notag` hoặc `equation*`/`align*`.
  Nhiều dòng: `align` với `&=`. Dấu thập phân trong công thức giữ dấu chấm như gốc (0.5) để khớp sách; trong văn bản tiếng Việt cũng giữ như gốc để tránh nhầm với công thức.
- Ký hiệu trong preamble: \Softmax \Sigmoid \ReLU \LN \FFN \Att \KL \argmax \argmin \R \E. Có thể dùng \mathrm{...} cho tên hàm khác. KHÔNG thêm \usepackage hay \newcommand toàn cục;
  nếu thật sự cần macro riêng, định nghĩa bằng `\providecommand` ngay trong file của bạn với tên có tiền tố của bạn (vd `\cZaX`).
- Chú thích chân trang của tác giả → `\footnote{...}` (dịch). Chú thích ngắn của người dịch → `\ndfoot{...}`.
- Hộp văn bản / ví dụ prompt / hội thoại đóng khung trong gốc → `\begin{hopvd} ... \end{hopvd}` và **dịch nội dung** sang tiếng Việt
  (riêng mã nguồn, ký hiệu đặc biệt, token như `[CLS]`, `<s>` giữ nguyên). Nếu ví dụ minh họa chính một hiện tượng tiếng Anh
  (tách từ tiếng Anh, lỗi chính tả tiếng Anh, chơi chữ...), giữ nguyên câu tiếng Anh và thêm bản dịch nghĩa trong ngoặc hoặc dòng dưới.
  Trong hopvd, dùng `\textbf{}` cho nhãn, xuống dòng bằng đoạn mới hoặc `\\`. Ký tự đặc biệt LaTeX (# $ % & _ { } ~ ^ \) phải escape.
- Bảng → dịch và dàn lại bằng `tabular` (booktabs) trong `\begin{bang} \chuthichbang{3.1}{...} \begin{tabular}...\end{tabular} \end{bang}`.
  Bảng quá rộng: `\resizebox{\linewidth}{!}{...}` hoặc `\small`/`\footnotesize`.
- Thuật toán (Algorithm) → `algorithm` + `algorithmic` (algpseudocode), dịch phần chữ; caption: `\caption*{\textbf{Thuật toán 5.1:} ...}`.
- **Hình vẽ (sơ đồ, đồ thị, biểu đồ)**: KHÔNG vẽ lại. Chèn vector từ PDF gốc:
  1. Chạy `python3 BOOK/figbox.py <trang> "Figure 2.4"` → in ra `<trang> {x0 y0 x1 y1}` và đường dẫn ảnh xem trước.
  2. Xem ảnh xem trước bằng Read để chắc khung đúng: chứa ĐỦ hình (kể cả nhãn con (a)(b)), KHÔNG lẫn chú thích "Figure..." hay đoạn văn.
     Nếu sai, chạy `python3 BOOK/figbox.py <trang> --y TOP BOTTOM` (tọa độ bp tính từ đỉnh trang, trang cao 737) để chỉnh tay.
  3. Viết:
     ```
     \begin{hinh}
     \hinhgoc{75}{74.0 330.0 458.0 674.5}
     \chuthichhinh{2.4}{<chú thích đã dịch đầy đủ>}
     \end{hinh}
     ```
  Nếu hình chứa nhiều chữ tiếng Anh quan trọng cho việc hiểu, thêm 1–2 câu (hoặc một chú giải) giải nghĩa các nhãn chính.
  Hình mà thực chất là hộp văn bản (ví dụ prompt, hội thoại) → không cắt ảnh, mà dịch thành `hopvd`, giữ số hình bằng `\chuthichhinh`.

## Chú giải của người dịch (phần giá trị gia tăng quan trọng)
Bạn đọc đã học: đại số & hàm số, vectơ 2D/3D, lượng giác, đạo hàm 1 biến, tích phân cơ bản, logarit/mũ, tổ hợp – xác suất cổ điển, thống kê mô tả.
Bạn đọc CHƯA học: ma trận và phép nhân ma trận, vectơ nhiều chiều, đạo hàm riêng/gradient, quy tắc chuỗi nhiều biến, xác suất có điều kiện &
định lý Bayes, kỳ vọng/phương sai của biến ngẫu nhiên, entropy, tối ưu hóa, lập trình/thuật toán, kiến thức ngôn ngữ học, và mọi khái niệm học máy.
- Dùng `\begin{chuthich}[Tiêu đề ngắn] ... \end{chuthich}` đặt NGAY SAU đoạn văn có khái niệm khó. Nội dung: giải thích trực giác bằng lời giản dị,
  ví dụ bằng số cụ thể nhỏ (tính tay được), so sánh đời thường, liên hệ kiến thức THPT, giải thích ý nghĩa từng ký hiệu trong công thức quan trọng.
- Mật độ hợp lý: khoảng 1 khung mỗi 1–2 trang gốc, nhiều hơn ở chỗ toán dày hoặc khái niệm mới; mỗi khung ngắn gọn (thường 3–12 dòng). Không giải thích lại
  điều sách vừa nói rõ; không lặp lại chú giải đã có cho khái niệm cơ bản nếu chương trước đã giải thích (có thể nói "xem lại chú giải ở Mục x.y").
- Chú giải phải CHÍNH XÁC. Không thêm nhận định sai. Không viết "theo người dịch thì tác giả sai".
- Không sửa nội dung gốc: phần dịch là bản dịch trung thành; mọi bổ sung chỉ nằm trong `chuthich` hoặc `\ndfoot`.

## Kiểm tra (bắt buộc trước khi kết thúc)
1. Biên dịch: `CH=<số chương> SEC=<số mục đã qua> SUB=<số tiểu mục đã qua> bash BOOK/test_chunk.sh chapters/<id>.tex`
   (bỏ CH/SEC/SUB nếu file bắt đầu bằng \chapter; ví dụ phần bắt đầu ở Mục 6.3 → `CH=6 SEC=2`; bắt đầu ở 6.4.5 → `CH=6 SEC=4 SUB=4`).
   Sửa hết lỗi. Đảm bảo số mục/tiểu mục in ra khớp với gốc.
2. Rasterize và xem nhanh 3–4 trang kết quả (đặc biệt trang có hình và công thức lớn):
   `pdftoppm -r 70 -png -f N -l N BOOK/build/t_<id>.pdf /tmp/.../x` rồi Read ảnh. Sửa hình bị cắt sai/tràn lề.
3. Đối chiếu đủ: liệt kê các số phương trình, hình, bảng, footnote trong phạm vi gốc và chắc chắn tất cả đều có trong file
   (vd `grep -o '\\tag{[0-9.]*}' file | wc -l` so với số phương trình trong gốc).
4. Không có chữ tiếng Anh sót lại ngoài: thuật ngữ trong ngoặc, tên riêng, ví dụ cố ý giữ, mã.

## Báo cáo cuối (ngắn, ≤ 15 dòng)
- File đã tạo, số trang PDF thử, số phương trình/hình/bảng đã có so với gốc, số khung chú giải.
- Những chỗ còn nghi ngờ/chưa chắc (nếu có).
Không dán nội dung bản dịch vào báo cáo.
