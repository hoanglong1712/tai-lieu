#!/usr/bin/env python3
"""Sinh chapters/z_glossary.tex từ build/main.tng (ghi bởi \\tn/\\tnb) + glossary.md + terms_*.md."""
import os, re, glob, unicodedata
from collections import Counter, defaultdict
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # thư mục gốc dự án
pairs = defaultdict(Counter)

def add(en, vi):
    en = en.strip(); vi = vi.strip()
    if not en or not vi or len(en) > 80: return
    vi = vi[0].lower() + vi[1:] if vi[:1].isupper() and not vi[:2].isupper() else vi
    pairs[en][vi] += 1

tng = os.path.join(HERE, "build", "main.tng")
if os.path.exists(tng):
    for line in open(tng, encoding="utf-8"):
        if "|" in line:
            en, vi = line.rstrip("\n").split("|", 1); add(en, vi)
for f in [os.path.join(HERE, "glossary.md")] + glob.glob(os.path.join(HERE, "thuat_ngu", "terms_*.md")):
    for line in open(f, encoding="utf-8"):
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) >= 2 and cells[0] and not set(cells[0]) <= set("-: ") and cells[0] != "English":
            add(cells[0], re.sub(r"\(giữ\)", "", cells[1]))

def tex(s):
    if re.search(r"\$[^$]+\$", s) or re.search(r"\\[a-zA-Z]+", s):
        return s  # đã là LaTeX hợp lệ (công thức/macro) – giữ nguyên
    s = s.replace("\\", "\\textbackslash{}")
    for ch in "&%$#_{}":
        s = s.replace(ch, "\\" + ch)
    return s.replace("~", "\\textasciitilde{}").replace("^", "\\textasciicircum{}")

def key(en):
    return re.sub(r"[^a-z0-9 ]", "", unicodedata.normalize("NFKD", en.lower()))

# gộp theo khóa chuẩn hóa
merged = defaultdict(Counter); shown = {}
for en, c in pairs.items():
    k = key(en)
    if not k.strip(): continue
    merged[k].update(c); shown.setdefault(k, en)
out = ["\\chapter{Bảng thuật ngữ Anh -- Việt}",
       "Bảng dưới đây tập hợp các thuật ngữ dùng trong bản dịch (sắp xếp theo tiếng Anh). Khi một thuật ngữ có nhiều cách dịch, cách dịch dùng nhiều nhất được ghi trước.\\par\\medskip",
       "{\\small", "\\begin{longtable}{@{}p{0.42\\linewidth}p{0.54\\linewidth}@{}}", "\\toprule \\textbf{Tiếng Anh} & \\textbf{Tiếng Việt}\\\\ \\midrule \\endhead"]
letter = None
for k in sorted(merged):
    L = k[0].upper()
    if L != letter:
        letter = L; out.append(f"\\multicolumn{{2}}{{@{{}}l}}{{\\textbf{{\\sffamily {L}}}}}\\\\[1pt]")
    vis = [v for v, _ in merged[k].most_common(3)]
    out.append(f"\\textit{{{tex(shown[k])}}} & {tex('; '.join(vis))}\\\\")
out += ["\\bottomrule", "\\end{longtable}", "}"]
open(os.path.join(HERE, "chapters", "z_glossary.tex"), "w", encoding="utf-8").write("\n".join(out) + "\n")
print(len(merged), "thuật ngữ")
