#!/bin/bash
# Biên dịch thử MỘT file phần dịch:  bash test_chunk.sh chapters/c01_a.tex
# Kết quả: build/<tên>.pdf ; in ra lỗi LaTeX nếu có.
# Nếu file KHÔNG bắt đầu bằng \chapter (phần giữa chương), đặt biến CH=số chương để số mục khớp, vd: CH=1 SEC=3 bash test_chunk.sh ...
set -u
cd "$(dirname "$0")/.."
F="$1"; N=$(basename "$F" .tex)
mkdir -p build
CH=${CH:-}; SEC=${SEC:-}; SUB=${SUB:-}
cat > build/t_$N.tex <<EOF
\\documentclass[10pt,openany]{book}
\\input{preamble.tex}
\\begin{document}
\\mainmatter
$( [ -n "$CH" ] && echo "\\setcounter{chapter}{$CH}" )
$( [ -n "$SEC" ] && echo "\\setcounter{section}{$SEC}" )
$( [ -n "$SUB" ] && echo "\\setcounter{subsection}{$SUB}" )
\\input{$F}
\\end{document}
EOF
( cd build && TEXINPUTS=..: timeout 600 xelatex -interaction=nonstopmode -halt-on-error t_$N.tex > t_$N.stdout 2>&1 )
rc=$?
if [ $rc -ne 0 ] || grep -q "^!" build/t_$N.log; then
  echo "=== LỖI biên dịch ($F) ==="; grep -A6 "^!" build/t_$N.log | head -40
else
  echo "OK: build/t_$N.pdf ($(pdfinfo build/t_$N.pdf | grep Pages))"
  grep -E "Overfull \\\\hbox \(([5-9][0-9]|[0-9]{3,})" build/t_$N.log | head -5
  grep -iE "Missing character" build/t_$N.log | sort | uniq | head -5
fi
