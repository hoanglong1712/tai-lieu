#!/usr/bin/env python3
"""Tìm khung (viewport) của một hình vẽ trong orig.pdf để chèn dạng vector bằng \\hinhgoc.

Cách dùng:
  python3 figbox.py PAGE "Figure 2.4"        # tự tìm vùng hình nằm phía trên chú thích "Figure 2.4:"
  python3 figbox.py PAGE --y TOP BOTTOM       # chỉ định thủ công dải dọc (tọa độ bp tính từ ĐỈNH trang)

In ra:  PAGE {x0 y0 x1 y1}   (dùng trực tiếp:  \\hinhgoc{PAGE}{x0 y0 x1 y1})
và ghi ảnh xem trước figprev/p<PAGE>_<label>.png để kiểm tra bằng mắt.
"""
import sys, os, re, subprocess, html
import xml.etree.ElementTree as ET
from PIL import Image

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # thư mục gốc dự án
PDF = os.path.join(HERE, "orig.pdf")
PW, PH = 524.409, 737.008
DPI = 144
S = DPI / 72.0

def blocks(page):
    out = subprocess.run(["pdftotext", "-f", str(page), "-l", str(page), "-bbox-layout", PDF, "-"],
                         capture_output=True, text=True).stdout
    out = re.sub(r'<!DOCTYPE[^>]*>', '', out)
    out = out.replace('xmlns="http://www.w3.org/1999/xhtml"', '')
    out = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', out)
    out = re.sub(r'&(?!(amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)', '&amp;', out)
    root = ET.fromstring(out)
    res = []
    for b in root.iter('block'):
        words = [w.text or '' for w in b.iter('word')]
        lines = len(list(b.iter('line')))
        res.append(dict(x0=float(b.get('xMin')), y0=float(b.get('yMin')), x1=float(b.get('xMax')),
                        y1=float(b.get('yMax')), text=' '.join(words), lines=lines))
    return res

def render(page):
    os.makedirs(os.path.join(HERE, "figprev"), exist_ok=True)
    base = os.path.join(HERE, "figprev", f"_r{page}")
    if not os.path.exists(base + ".png"):
        subprocess.run(["pdftoppm", "-f", str(page), "-l", str(page), "-r", str(DPI), "-png", "-singlefile", PDF, base], check=True)
    return Image.open(base + ".png").convert("L")

def ink_bbox(img, top, bot):
    """bbox (bp, gốc trên) của mực trong dải [top,bot]."""
    W, H = img.size
    t, b = int(top * S), int(bot * S)
    crop = img.crop((0, max(t, 0), W, min(b, H)))
    inv = crop.point(lambda v: 255 if v < 235 else 0)
    bb = inv.getbbox()
    if not bb:
        return None
    return (bb[0] / S, (bb[1] + t) / S, bb[2] / S, (bb[3] + t) / S)

def main():
    page = int(sys.argv[1])
    bl = blocks(page)
    img = render(page)
    label = "manual"
    if len(sys.argv) >= 5 and sys.argv[2] == "--y":
        top, bot = float(sys.argv[3]), float(sys.argv[4])
    else:
        label = sys.argv[2]
        key = label.strip()
        cap = [b for b in bl if b['text'].startswith(key + ":") or b['text'].startswith(key + " ")]
        if not cap:
            cap = [b for b in bl if key in b['text']]
        if not cap:
            sys.exit(f"Không thấy chú thích '{key}' trên trang {page}. Dùng --y TOP BOTTOM.")
        c = cap[0]
        bot = c['y0'] - 2
        top = 60.0  # dưới header
        # khối văn bản thân bài (rộng, nhiều dòng) gần nhất phía trên chú thích
        for b in bl:
            if b['y1'] <= c['y0'] - 1 and (b['x1'] - b['x0']) > 330 and b['lines'] >= 2 and b['y1'] > top:
                top = b['y1'] + 2
        # dòng header
        for b in bl:
            if b['y1'] < 60 and b['y1'] + 2 > top:
                top = b['y1'] + 4
    bb = ink_bbox(img, top, bot)
    if not bb:
        sys.exit("Không tìm thấy nét vẽ trong dải đã chọn.")
    pad = 3
    x0, yt, x1, yb = bb[0] - pad, bb[1] - pad, bb[2] + pad, bb[3] + pad
    vp = f"{x0:.1f} {PH - yb:.1f} {x1:.1f} {PH - yt:.1f}"
    safe = re.sub(r'[^0-9A-Za-z.]+', '_', label)
    prev = os.path.join(HERE, "figprev", f"p{page}_{safe}.png")
    img.crop((int(x0 * S), int(yt * S), int(x1 * S), int(yb * S))).save(prev)
    print(f"{page} {{{vp}}}   preview: {prev}   (dải dọc từ đỉnh: {yt:.1f}-{yb:.1f})")

if __name__ == "__main__":
    main()
