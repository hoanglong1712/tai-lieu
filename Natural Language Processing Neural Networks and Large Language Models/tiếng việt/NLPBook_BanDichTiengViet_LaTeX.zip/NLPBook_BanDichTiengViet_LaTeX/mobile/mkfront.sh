#!/bin/bash
cd "$(dirname "$0")"
cat > Front.tex <<'T'
\documentclass[10pt,openany]{book}
\input{preamble_mobile.tex}
\begin{document}
\frontmatter
\input{chapters/c00_front.tex}
\input{chapters/c00_preface.tex}
\renewcommand{\contentsname}{Mục lục}
\end{document}
T
cat > Gloss.tex <<'T'
\documentclass[10pt,openany]{book}
\input{preamble_mobile.tex}
\begin{document}
\backmatter
\renewcommand{\chaptermark}[1]{\markboth{#1}{#1}}
\input{chapters/z_glossary.tex}
\end{document}
T
for f in Front Gloss; do TEXINPUTS=..: timeout 900 xelatex -interaction=nonstopmode $f.tex > $f.stdout 2>&1; echo "$f err=$(grep -c '^!' $f.log) pages=$(pdfinfo $f.pdf | awk '/Pages/{print $2}')"; done
