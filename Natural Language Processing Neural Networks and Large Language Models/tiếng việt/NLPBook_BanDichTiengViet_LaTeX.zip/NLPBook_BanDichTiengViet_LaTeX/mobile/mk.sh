#!/bin/bash
# mk.sh N "c01_a c01_b c01_c"  -> mobile/ChuongNN.pdf
cd "$(dirname "$0")"
N=$1; shift; PARTS="$*"
F=Chuong$(printf %02d $N)
{
echo '\documentclass[10pt,openany]{book}'
echo '\input{preamble_mobile.tex}'
echo '\begin{document}\mainmatter'
echo "\\setcounter{chapter}{$((N-1))}"
for p in $PARTS; do echo "\\input{chapters/$p.tex}"; done
echo '\clearpage\thispagestyle{empty}\vspace*{\fill}{\footnotesize\noindent Bản dịch tiếng Việt có chú giải (không chính thức, phi thương mại) của \emph{Natural Language Processing: Neural Networks and Large Language Models}, \textcopyright{} 2021--2026 Tong Xiao và Jingbo Zhu, \url{https://github.com/NiuTrans/NLPBook}. Nguyên tác và bản dịch theo giấy phép CC BY-NC 4.0.\par}'
echo '\end{document}'
} > $F.tex
TEXINPUTS=..: xelatex -interaction=nonstopmode $F.tex > $F.stdout 2>&1
echo "$F rc=$? err=$(grep -c '^!' $F.log) pages=$(pdfinfo $F.pdf 2>/dev/null | awk '/Pages/{print $2}') overfull>10pt=$(grep -cE 'Overfull \\hbox \(([1-9][0-9]|[0-9]{3,})' $F.log)"
