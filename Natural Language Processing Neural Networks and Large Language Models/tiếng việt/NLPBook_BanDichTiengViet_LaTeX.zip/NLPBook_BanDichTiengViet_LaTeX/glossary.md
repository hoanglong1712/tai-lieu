# Bảng thuật ngữ chuẩn (BẮT BUỘC dùng thống nhất)

Quy tắc: lần đầu một thuật ngữ xuất hiện TRONG MỖI CHƯƠNG → dùng `\tn{tiếng Việt}{English}` (hoặc `\tnb` nếu sách gốc in đậm). Các lần sau chỉ viết tiếng Việt.
Các thuật ngữ đánh dấu (giữ) thì giữ nguyên tiếng Anh trong văn bản (vẫn có thể giải thích lần đầu).
Nếu gặp thuật ngữ chưa có ở đây: tự chọn cách dịch phổ biến trong cộng đồng AI Việt Nam, và ghi thêm vào file `terms_<id phần>.md` của mình.

| English | Tiếng Việt |
|---|---|
| natural language processing (NLP) | xử lý ngôn ngữ tự nhiên (NLP) |
| artificial intelligence (AI) | trí tuệ nhân tạo (AI) |
| machine learning (ML) | học máy |
| deep learning | học sâu |
| neural network | mạng nơ-ron |
| neuron | nơ-ron |
| layer / hidden layer | tầng / tầng ẩn |
| multi-layer perceptron | perceptron nhiều tầng |
| activation function | hàm kích hoạt |
| weight / bias | trọng số / độ lệch (bias) |
| parameter / hyperparameter | tham số / siêu tham số |
| loss function | hàm mất mát |
| objective function | hàm mục tiêu |
| gradient | gradient (giữ) |
| gradient descent | hạ gradient (gradient descent) |
| stochastic gradient descent (SGD) | hạ gradient ngẫu nhiên (SGD) |
| learning rate | tốc độ học |
| back-propagation | lan truyền ngược |
| forward pass / backward pass | lượt truyền xuôi / lượt truyền ngược |
| computation graph | đồ thị tính toán |
| training / inference | huấn luyện / suy luận |
| training set / validation set / test set | tập huấn luyện / tập kiểm định / tập kiểm tra |
| overfitting / underfitting | quá khớp / chưa khớp |
| regularization | chính quy hóa |
| dropout | dropout (giữ) |
| batch / mini-batch | lô / lô nhỏ |
| epoch | epoch (giữ) |
| feature / feature vector | đặc trưng / vectơ đặc trưng |
| classifier / classification | bộ phân loại / phân loại |
| supervised / unsupervised / self-supervised learning | học có giám sát / không giám sát / tự giám sát |
| reinforcement learning (RL) | học tăng cường |
| reward / reward model | phần thưởng / mô hình phần thưởng |
| policy | chính sách (policy) |
| probability distribution | phân phối xác suất |
| conditional probability | xác suất có điều kiện |
| maximum likelihood estimation (MLE) | ước lượng hợp lý cực đại (MLE) |
| cross-entropy | entropy chéo |
| scalar / vector / matrix / tensor | vô hướng / vectơ / ma trận / tensor |
| dot product | tích vô hướng |
| element-wise | theo từng phần tử |
| transpose | chuyển vị |
| dimension | chiều |
| corpus (pl. corpora) | kho ngữ liệu |
| token / tokenization | token (giữ) / tách token |
| vocabulary | bộ từ vựng |
| out-of-vocabulary (OOV) word | từ ngoài bộ từ vựng (OOV) |
| subword | từ con (subword) |
| word embedding / embedding | nhúng từ / vectơ nhúng (embedding) |
| representation | biểu diễn |
| language model / language modeling | mô hình ngôn ngữ / mô hình hóa ngôn ngữ |
| large language model (LLM) | mô hình ngôn ngữ lớn (LLM) |
| sequence / sequence labeling | chuỗi / gán nhãn chuỗi |
| sequence-to-sequence | chuỗi-sang-chuỗi |
| encoder / decoder | bộ mã hóa / bộ giải mã |
| attention / self-attention / multi-head attention | cơ chế chú ý / tự chú ý / chú ý đa đầu |
| query / key / value | truy vấn / khóa / giá trị |
| Transformer | Transformer (giữ) |
| positional encoding / embedding | mã hóa vị trí / nhúng vị trí |
| layer normalization | chuẩn hóa tầng |
| residual connection | kết nối tắt (residual) |
| feed-forward network (FFN) | mạng truyền thẳng (FFN) |
| recurrent neural network (RNN) | mạng nơ-ron hồi quy (RNN) |
| convolutional neural network (CNN) | mạng nơ-ron tích chập (CNN) |
| long short-term memory (LSTM) | bộ nhớ dài-ngắn hạn (LSTM) |
| hidden state | trạng thái ẩn |
| context / context window | ngữ cảnh / cửa sổ ngữ cảnh |
| pre-training / fine-tuning | tiền huấn luyện / tinh chỉnh |
| instruction fine-tuning | tinh chỉnh theo chỉ dẫn |
| supervised fine-tuning (SFT) | tinh chỉnh có giám sát (SFT) |
| prompt / prompting / prompt engineering | prompt (giữ) / kỹ thuật prompt / thiết kế prompt |
| in-context learning | học trong ngữ cảnh |
| few-shot / zero-shot | few-shot / zero-shot (giữ) |
| chain of thought (CoT) | chuỗi suy nghĩ (CoT) |
| alignment | căn chỉnh (alignment) |
| human preference | sở thích (ưu tiên) của con người |
| reasoning | lập luận (reasoning) — phân biệt với inference = "suy luận" (chạy mô hình) |
| decoding / beam search / greedy search | giải mã / tìm kiếm chùm (beam search) / tìm kiếm tham lam |
| sampling | lấy mẫu |
| scaling law | định luật co giãn (scaling law) |
| hallucination | ảo giác (hallucination) |
| retrieval-augmented generation (RAG) | sinh văn bản tăng cường truy xuất (RAG) |
| machine translation | dịch máy |
| speech recognition | nhận dạng tiếng nói |
| inductive bias | thiên kiến quy nạp |
| generative / discriminative model | mô hình sinh / mô hình phân biệt |
| smoothing | làm trơn |
| auto-encoder | bộ tự mã hóa |
| KV cache | bộ nhớ đệm KV (KV cache) |
| benchmark | bộ đánh giá chuẩn (benchmark) |
| baseline | mô hình cơ sở (baseline) |
| state-of-the-art | tiên tiến nhất |
