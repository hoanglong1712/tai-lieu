foundation model | mô hình nền tảng
backbone model | mô hình xương sống
masked language modeling | mô hình hóa ngôn ngữ có che
causal language modeling | mô hình hóa ngôn ngữ nhân quả
permuted language modeling | mô hình hóa ngôn ngữ hoán vị
prefix language modeling | mô hình hóa ngôn ngữ tiền tố
self-training | tự huấn luyện
seed data / pseudo-label | dữ liệu hạt giống / nhãn giả
bootstrap | tự nâng cấp
word sense disambiguation | khử nhập nhằng nghĩa của từ
local minima | cực tiểu địa phương
regularizer | bộ chính quy hóa
sentiment analysis / polarity | phân tích cảm xúc / cực tính
freeze (parameters) | đóng băng
completion | phần hoàn thành
demonstrations | ví dụ minh họa
decoder-only / encoder-only | chỉ có bộ giải mã / chỉ có bộ mã hóa
cross-attention | chú ý chéo
one-hot representation | biểu diễn one-hot
permutation-invariant | bất biến với hoán vị
mask (attention) | mặt nạ
next sentence prediction (NSP) | dự đoán câu tiếp theo (NSP)
separator | ký hiệu phân tách
positive / negative sample | mẫu dương / mẫu âm
generator / discriminator | bộ sinh / bộ phân biệt
generative adversarial networks (GAN) | mạng đối sinh (GAN)
text-to-text | văn bản-sang-văn bản
denoising autoencoder | bộ tự mã hóa khử nhiễu
span / sentinel token | đoạn / token canh gác
fertility modeling | mô hình hóa độ sinh sản
robust | bền vững
multilingual / cross-lingual | đa ngôn ngữ / xuyên ngôn ngữ
