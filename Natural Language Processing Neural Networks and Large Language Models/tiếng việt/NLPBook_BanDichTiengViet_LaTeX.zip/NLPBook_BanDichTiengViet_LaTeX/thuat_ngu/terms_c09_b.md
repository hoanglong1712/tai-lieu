problem decomposition | phân rã bài toán
divide-and-conquer | chia để trị
least-to-most prompting | prompting từ dễ đến khó
sub-problem generation / solving | sinh bài toán con / giải bài toán con
multi-hop question answering | hỏi đáp đa bước
semantic parsing | phân tích ngữ nghĩa
compositionality / compositional generalization | tính kết hợp / khái quát hóa kết hợp
self-refinement | tự tinh chỉnh
self-reflection | tự phản tư
part-of-speech (POS) tagging | gán nhãn từ loại
deliberate-then-generate (DTG) | cân nhắc rồi sinh (DTG)
negative evidence | bằng chứng phủ định
model ensembling / ensemble learning | kết hợp mô hình / học kết hợp
prompt ensembling / output ensembling | kết hợp prompt / kết hợp đầu ra
text simplification | đơn giản hóa văn bản
latent variable | biến ẩn
prior distribution | phân phối tiên nghiệm
Monte Carlo sampling | lấy mẫu Monte Carlo
self-consistency | tự nhất quán
hypothesis selection | lựa chọn giả thuyết
minimum Bayes risk | rủi ro Bayes cực tiểu
verifier / outcome-based / process-based | bộ kiểm chứng / dựa trên kết quả / dựa trên quá trình
vector database | cơ sở dữ liệu vectơ
tool use | sử dụng công cụ
autonomous agent | tác tử tự hành
