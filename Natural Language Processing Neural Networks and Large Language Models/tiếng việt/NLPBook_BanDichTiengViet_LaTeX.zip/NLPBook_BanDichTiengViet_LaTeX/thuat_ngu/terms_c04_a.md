stochastic process / random process | quá trình ngẫu nhiên
time series | chuỗi thời gian
joint probability | xác suất đồng thời
error gradient | gradient lỗi
back-propagation through time (BPTT) | lan truyền ngược theo thời gian (BPTT)
exploding / vanishing gradient | bùng nổ gradient / tiêu biến gradient
gradient clipping | cắt gradient
truncated back-propagation | lan truyền ngược bị cắt ngắn
saturating / non-saturating activation | hàm kích hoạt bão hòa / không bão hòa
skip connection | kết nối nhảy
autoregressive process | quá trình tự hồi quy
uni-directional / bi-directional model | mô hình một chiều / hai chiều
memory | bộ nhớ (trí nhớ trong ngữ cảnh tâm lý học)
multi-store model | mô hình đa kho
sensory / short-term / long-term memory | trí nhớ giác quan / ngắn hạn / dài hạn
information retrieval (IR) | truy xuất thông tin (IR)
end-to-end memory network | mạng bộ nhớ đầu-cuối
neural Turing machine | máy Turing nơ-ron
external memory | bộ nhớ ngoài
recurrent cell / memory cell | ô hồi quy / ô nhớ
forget gate / input gate / output gate | cổng quên / cổng vào / cổng ra
gated recurrent unit (GRU) | đơn vị hồi quy có cổng (GRU)
reset gate / update gate | cổng đặt lại / cổng cập nhật
