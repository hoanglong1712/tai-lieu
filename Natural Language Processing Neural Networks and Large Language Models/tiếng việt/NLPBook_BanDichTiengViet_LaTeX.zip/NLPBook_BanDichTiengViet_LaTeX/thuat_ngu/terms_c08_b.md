web scraping | thu thập dữ liệu web tự động
heuristic | quy tắc kinh nghiệm
downstream task | nhiệm vụ hạ nguồn
cross-lingual | xuyên ngôn ngữ
low-resource language | ngôn ngữ ít tài nguyên
gender bias | thiên lệch giới tính
class imbalance | mất cân bằng lớp
anonymize | ẩn danh hóa
diverge | phân kỳ
internal covariate shift | dịch chuyển hiệp biến nội tại
post-norm / pre-norm | chuẩn hóa sau / chuẩn hóa trước
gain | hệ số khuếch đại
RMS layer normalization | chuẩn hóa tầng theo căn trung bình bình phương
degeneration | suy biến
hidden size | kích thước ẩn
GeLU | đơn vị tuyến tính sai số Gauss
GLU | đơn vị tuyến tính có cổng
affine transformation | phép biến đổi affine
rotary position embedding | nhúng vị trí xoay
learning rate scheduling | lịch điều chỉnh tốc độ học
mixed-precision training | huấn luyện độ chính xác hỗn hợp
data/model/tensor/pipeline parallelism | song song dữ liệu/mô hình/tensor/đường ống
worker | máy thực thi
micro-batch | lô vi mô
throughput | thông lượng
stale gradient | gradient lỗi thời
fault-tolerant | chịu lỗi
gradient accumulation | tích lũy gradient
overflow / underflow | tràn trên / tràn dưới
emergent abilities | năng lực đột sinh
irreducible error | lỗi không thể khử
double descent | suy giảm kép
long-context LLM | LLM ngữ cảnh dài
sequence parallelism | song song chuỗi
collective operation | phép toán tập thể
sparse attention / linear attention | chú ý thưa / chú ý tuyến tính
kernel function | hàm nhân
state space model | mô hình không gian trạng thái
