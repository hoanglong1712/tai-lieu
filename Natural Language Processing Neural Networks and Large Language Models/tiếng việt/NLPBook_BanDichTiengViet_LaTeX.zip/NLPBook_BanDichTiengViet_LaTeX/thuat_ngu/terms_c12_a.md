reasoning (chương 12) | lập luận
inference-time scaling | mở rộng quy mô lúc suy luận
inference-time compute | lượng tính toán lúc suy luận
reasoning model | mô hình lập luận
reasoning path / reasoning step | đường lập luận / bước lập luận
deduction / induction / abduction | diễn dịch / quy nạp / giả định (suy ra lời giải thích tốt nhất)
dual-process theory | thuyết quá trình kép
emergent ability | năng lực trỗi dậy
cascading errors | lỗi lan truyền dây chuyền
self-consistency | tự nhất quán
self-reflection | tự phản tư
self-correction | tự sửa lỗi
verifier / generative verification | bộ kiểm chứng / kiểm chứng sinh
outcome / process reward model (ORM/PRM) | mô hình phần thưởng theo kết quả / theo quá trình
reward hacking | khai thác lỗ hổng phần thưởng
Monte Carlo rollouts | triển khai thử Monte Carlo
search scaling | mở rộng quy mô tìm kiếm
temperature sampling / nucleus sampling | lấy mẫu với nhiệt độ / lấy mẫu hạt nhân
exploration–exploitation trade-off | đánh đổi giữa khám phá và khai thác
reference policy | chính sách tham chiếu
formal symbolic system | hệ thống ký hiệu hình thức
indicator function | hàm chỉ thị
false positive | dương tính giả
