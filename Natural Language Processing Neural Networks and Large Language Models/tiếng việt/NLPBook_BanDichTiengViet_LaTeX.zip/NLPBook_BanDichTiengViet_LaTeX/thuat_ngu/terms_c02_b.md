recurrent unit / recurrent cell | đơn vị hồi quy / ô hồi quy
unrolled / unfolded / rolled | trải phẳng / mở rộng / cuộn
back-propagation through time (BPTT) | lan truyền ngược theo thời gian (BPTT)
time step | bước thời gian
concatenation | ghép nối
receptive field | trường tiếp nhận
convolutional layer / pooling layer | tầng tích chập / tầng gộp
convolution kernel / filter | nhân tích chập / bộ lọc
stride | bước trượt
padding | đệm
parameter sharing / weight sharing | chia sẻ tham số / chia sẻ trọng số
max pooling / average pooling | gộp cực đại / gộp trung bình
down-sampling | giảm mẫu
gate / gating vector / update gate / forget gate | cổng / vectơ cổng / cổng cập nhật / cổng quên
normalization / standardization | chuẩn hóa / chuẩn tắc hóa
residual connection / skip connection / shortcut connection | kết nối tắt (residual) / kết nối bỏ qua / kết nối đường tắt
residual block / identity mapping | khối phần dư / ánh xạ đồng nhất
vanishing / exploding gradient | gradient biến mất / gradient bùng nổ
steepest descent | hạ dốc nhất
update rule / delta rule | quy tắc cập nhật / quy tắc delta
momentum | động lượng (quán tính)
outer product | tích ngoài
decay factor | hệ số suy giảm
root mean square (RMS) | căn quân phương
first moment / second raw moment | mô-men bậc nhất / mô-men gốc bậc hai
bias correction | hiệu chỉnh độ lệch
moving average | trung bình trượt
stopping criterion / early stopping | tiêu chí dừng / dừng sớm
batching / batch gradient descent / mini-batch gradient descent | chia lô / hạ gradient theo toàn lô / hạ gradient theo lô nhỏ
ground truth | đáp án chuẩn
fan-in / fan-out | số đầu vào / số đầu ra
random seed | hạt giống ngẫu nhiên
learning rate scheduling / warmup | lập lịch tốc độ học / khởi động
