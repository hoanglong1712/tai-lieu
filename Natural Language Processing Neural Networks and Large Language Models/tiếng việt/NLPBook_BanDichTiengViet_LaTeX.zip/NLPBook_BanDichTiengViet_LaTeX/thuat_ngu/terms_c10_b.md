reinforcement learning from human feedback (RLHF) | học tăng cường từ phản hồi của con người (RLHF)
state / state-value function / action-value function (Q-value function) | trạng thái / hàm giá trị trạng thái / hàm giá trị hành động (hàm giá trị Q)
value function | hàm giá trị
discounted return / return / cumulative reward | lợi tức chiết khấu / lợi tức / phần thưởng tích lũy
discount factor | hệ số chiết khấu
trajectory | quỹ đạo
performance function | hàm hiệu năng
policy gradient | gradient chính sách
sparse reward / reward shaping | phần thưởng thưa / định hình phần thưởng
Markov decision process | quá trình quyết định Markov
dynamics | động lực
variance | phương sai
baseline (in RL) | đường cơ sở
advantage | lợi thế
advantage actor-critic (A2C) / actor / critic | tác nhân--phê bình có lợi thế (A2C) / tác nhân / bộ phê bình
temporal difference (TD) | chênh lệch thời gian (TD)
Bradley-Terry model | mô hình Bradley--Terry
utility function | hàm tiện ích
importance sampling | lấy mẫu theo trọng số quan trọng
ratio function | hàm tỉ số
reference policy / reference model / target model | chính sách tham chiếu / mô hình tham chiếu / mô hình đích
surrogate objective | mục tiêu thay thế
clipping | cắt ngưỡng
trust region | vùng tin cậy
proximal policy optimization (PPO) | tối ưu chính sách cận kề (PPO)
