zero matrix | ma trận không
identity matrix | ma trận đơn vị
row vector / column vector | vectơ hàng / vectơ cột
matrix product | tích ma trận
norm / p-norm | chuẩn / chuẩn p
random variable | biến ngẫu nhiên
binary variable | biến nhị phân
probability measure | độ đo xác suất
sample space | không gian mẫu
probability function | hàm xác suất
joint probability | xác suất đồng thời
marginal probability | xác suất biên
product rule / chain rule (probability) | quy tắc nhân / quy tắc chuỗi
probability density (function, PDF) | mật độ xác suất (hàm mật độ xác suất)
probability mass function (PMF) | hàm khối xác suất
uniform / binomial / Bernoulli / Gaussian distribution | phân phối đều / nhị thức / Bernoulli / Gauss
expected value / expectation | giá trị kỳ vọng / kỳ vọng
variance / standard deviation | phương sai / độ lệch chuẩn
entropy | entropy
expected surprisal | độ bất ngờ kỳ vọng
relative entropy | entropy tương đối
KL divergence | độ phân kỳ KL
likelihood / log-likelihood / conditional likelihood | hàm hợp lý / log-hợp lý / hợp lý có điều kiện
likelihood ratio | tỉ số hợp lý
labels / tags / categories | nhãn / thẻ / hạng mục
document | tài liệu
(labeled) samples | mẫu (có nhãn)
classification model | mô hình phân loại
binary / multi-class / multi-label / single-label / hierarchical classification | phân loại nhị phân / đa lớp / đa nhãn / đơn nhãn / phân cấp
structure prediction | dự đoán cấu trúc
bag-of-words (BOW) model | mô hình túi từ (BOW)
vector space | không gian vectơ
representation learning | học biểu diễn
linear classifier | bộ phân loại tuyến tính
bias trick | mẹo gộp độ lệch
decision function / threshold function | hàm quyết định / hàm ngưỡng
linear discriminant function | hàm phân biệt tuyến tính
separating hyperplane / decision boundary | siêu phẳng phân tách / biên quyết định
linearly separable | tách được tuyến tính
Bayes' rule | quy tắc Bayes
prior | xác suất tiên nghiệm
data sparsity | tính thưa của dữ liệu
multinomial distribution | phân phối đa thức
log-linear model | mô hình log-tuyến tính
(multinomial/Bernoulli/Gaussian) naive Bayes | Bayes ngây thơ (đa thức/Bernoulli/Gauss)
logistic regression / logistic function / sigmoid function | hồi quy logistic / hàm logistic / hàm sigmoid
log-odds | log-odds
error-driven learning | học dựa trên lỗi
indicator function | hàm chỉ thị
0-1 loss / surrogate loss | hàm mất mát 0-1 / hàm mất mát thay thế
open-vocabulary | từ vựng mở
unseen words | từ chưa gặp
Zipf's Law | định luật Zipf
additive (add-α) smoothing | làm trơn cộng (cộng-α)
