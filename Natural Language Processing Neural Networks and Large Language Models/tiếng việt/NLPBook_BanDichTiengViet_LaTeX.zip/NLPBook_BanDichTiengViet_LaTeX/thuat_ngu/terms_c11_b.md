prefix caching | lưu đệm tiền tố
cache | lưu đệm / bộ nhớ đệm
prefilling | điền trước
batching | xử lý theo lô
padding / left padding | đệm / đệm bên trái
throughput | thông lượng
latency | độ trễ
disaggregate (prefilling and decoding) | tách rời (điền trước và giải mã)
scheduler / inference engine | bộ lập lịch / bộ máy suy luận
request-level scheduling | lập lịch mức yêu cầu
iteration-level scheduling | lập lịch mức vòng lặp
continuous batching | xử lý theo lô liên tục
compute-bound / memory-bound | bị giới hạn bởi tính toán / bị giới hạn bởi bộ nhớ
memory fragmentation | phân mảnh bộ nhớ
paged KV caching / paging | lưu đệm KV phân trang / phân trang
chunked prefilling | điền trước theo khúc
priority-based scheduling | lập lịch dựa trên mức ưu tiên
parallelization | song song hóa
load balancing | cân bằng tải
LLM serving | phục vụ LLM
quantization / pruning | lượng tử hóa / tỉa
knowledge distillation | chưng cất tri thức
memory-compute trade-off | đánh đổi bộ nhớ--tính toán
quality of service | chất lượng dịch vụ
inference-time scaling | co giãn lúc suy luận
inference-time compute scaling | co giãn tính toán lúc suy luận
context scaling / search scaling | co giãn ngữ cảnh / co giãn tìm kiếm
output ensembling / ensembling | kết hợp đầu ra / kết hợp
majority voting | bỏ phiếu đa số
meta-learner | bộ học meta
verifier | bộ kiểm chứng
best-of-N sampling | lấy mẫu tốt nhất trong N
parallel scaling / sequential scaling | co giãn song song / co giãn tuần tự
self-refinement | tự tinh chỉnh
tree search / step-level search | tìm kiếm cây / tìm kiếm mức bước
process reward model (PRM) | mô hình phần thưởng quá trình (PRM)
outcome reward model (ORM) | mô hình phần thưởng kết quả (ORM)
teacher model | mô hình thầy
value function | hàm giá trị
out-of-distribution | ngoài phân phối
reasoning (chương 11) | lập luận
