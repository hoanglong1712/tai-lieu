source-side / target-side sequence | chuỗi phía nguồn / chuỗi phía đích
discriminant function | hàm phân biệt
text generation | sinh văn bản
image captioning | chú thích ảnh
end-to-end | đầu-cuối
curse of dimensionality | lời nguyền số chiều
distributed representation | biểu diễn phân tán
neural machine translation (NMT) | dịch máy nơ-ron (NMT)
attention weight | trọng số chú ý
context vector | vectơ ngữ cảnh
alignment score | điểm gióng hàng
scaled dot-product attention | chú ý tích vô hướng có co giãn
multiplicative / additive attention | chú ý nhân / chú ý cộng
Euclidean norm | chuẩn Euclid
expectation | kỳ vọng
fusion layer | tầng hợp nhất
encoder-decoder attention | chú ý bộ mã hóa--bộ giải mã
feature subspace | không gian con đặc trưng
attention head | đầu chú ý
multi-branch neural network | mạng nơ-ron đa nhánh
single-layer / multi-layer attention | chú ý một tầng / chú ý nhiều tầng
identity mapping | ánh xạ đồng nhất
word alignment | gióng hàng từ
cascaded system | hệ thống nối tầng
local attention | chú ý cục bộ
reordering problem | bài toán sắp xếp lại trật tự
prior distribution | phân phối tiên nghiệm
fertility / coverage | độ sinh sản / độ bao phủ
dependency tree | cây phụ thuộc
addressing | định địa chỉ
modality / multi-modal model | phương thức / mô hình đa phương thức
co-attention | đồng chú ý
visual question answering (VQA) | hỏi đáp trực quan
permutation invariance | bất biến hoán vị
