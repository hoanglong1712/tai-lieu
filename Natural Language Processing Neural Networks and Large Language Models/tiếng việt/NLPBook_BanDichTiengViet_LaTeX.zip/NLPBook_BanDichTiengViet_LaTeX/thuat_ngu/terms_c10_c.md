pairwise / listwise / pointwise ranking | xếp hạng theo cặp / theo danh sách / theo điểm
Plackett-Luce model | mô hình Plackett-Luce
learning-to-rank | học để xếp hạng
underdetermination | tính bất định
sparse / dense rewards | phần thưởng thưa / dày
reward shaping / shaping reward function | định hình phần thưởng / hàm phần thưởng định hình
potential value | giá trị thế năng
curriculum learning | học theo giáo trình
intrinsic motivation | động lực nội tại
hindsight experience replay | phát lại kinh nghiệm nhìn lại
temporal-difference error | sai số chênh lệch thời gian
aspect-based sentiment analysis | phân tích cảm xúc theo khía cạnh
hinge loss | hàm mất mát bản lề
proxy | đại diện thay thế
overoptimization problem | vấn đề tối ưu hóa quá mức
reward hacking / reward gaming | lách phần thưởng / lợi dụng phần thưởng
Goodhart's law | định luật Goodhart
ensemble learning | học kết hợp
Bayesian model averaging | lấy trung bình mô hình Bayes
multi-objective optimization | tối ưu hóa đa mục tiêu
direct preference optimization (DPO) | tối ưu hóa sở thích trực tiếp (DPO)
normalization factor | hệ số chuẩn hóa
offline / online reinforcement learning | học tăng cường ngoại tuyến / trực tuyến
exploration | khám phá
AI feedback | phản hồi từ AI
outcome-based / process-based approaches | phương pháp dựa trên kết quả / dựa trên quá trình
active learning | học chủ động
Best-of-N (BoN) sampling | lấy mẫu tốt nhất trong N (BoN)
reranking | xếp hạng lại
rejection sampling | lấy mẫu loại bỏ
post-training | hậu huấn luyện
AI safety | an toàn AI
