auxiliary memory module | mô-đun bộ nhớ phụ trợ
local attention | chú ý cục bộ
moving average / cumulative average | trung bình trượt / trung bình tích lũy
heuristics | quy tắc kinh nghiệm
recurrent cell | ô hồi quy
segment | đoạn
sliding-chunk local memory | bộ nhớ cục bộ dạng khối trượt
compressive Transformer | Transformer nén
global tokens | token toàn cục
attention sink | bể hút chú ý
internal / external memories | bộ nhớ trong / bộ nhớ ngoài
memory-based methods | phương pháp dựa trên bộ nhớ
datastore | kho dữ liệu
k-nearest neighbors (k-NN) | k láng giềng gần nhất
vector database | cơ sở dữ liệu vectơ
gate | cổng
k-NN language modeling | mô hình hóa ngôn ngữ k-NN
classification head | đầu phân loại
information retrieval (IR) | truy xuất thông tin
space complexity | độ phức tạp không gian
sliding window attention | chú ý cửa sổ trượt
multi-query attention (MQA) | chú ý đa truy vấn
grouped query attention (GQA) | chú ý truy vấn theo nhóm
extrapolation / interpolation | ngoại suy / nội suy
relative positional embedding | nhúng vị trí tương đối
bucket | thùng
attention with linear biases (ALiBi) | chú ý với độ lệch tuyến tính
rotary positional embedding (RoPE) | nhúng vị trí xoay
position interpolation | nội suy vị trí
infinite context | ngữ cảnh vô hạn
perplexity | độ hỗn loạn
needle-in-a-haystack | mò kim đáy bể
passkey retrieval | truy xuất mật mã
copy memory task | tác vụ sao chép bộ nhớ
emergent ability | năng lực đột sinh
test-time compute | tính toán lúc kiểm tra
