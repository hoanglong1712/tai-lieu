step function | hàm bậc thang
affine transformation | phép biến đổi affine
linear transformation | phép biến đổi tuyến tính
discriminant function | hàm phân biệt
single-layer perceptron | perceptron một tầng
single-layer / multi-layer neural network | mạng nơ-ron một tầng / nhiều tầng
fully connected | kết nối đầy đủ
model depth / model width | độ sâu mô hình / độ rộng mô hình
representational capacity | năng lực biểu diễn
feed-forward neural network (FFNN) | mạng nơ-ron truyền thẳng
node / edge / root node | nút / cạnh / nút gốc
directed (graph) | có hướng
parsing | phân tích cú pháp
topologically sorted | sắp xếp tô-pô
partial derivative | đạo hàm riêng
chain rule of differentiation | quy tắc chuỗi của phép lấy đạo hàm
squared loss | hàm mất mát bình phương
backward pass / backpropagation | lượt truyền ngược / lan truyền ngược
n-gram language modeling | mô hình ngôn ngữ n-gram
relative frequency | tần suất tương đối
curse of dimensionality | lời nguyền số chiều
neural language model | mô hình ngôn ngữ nơ-ron
one-hot representation | biểu diễn one-hot
distributed representation | biểu diễn phân tán
embedding matrix | ma trận nhúng
concatenate | ghép nối
