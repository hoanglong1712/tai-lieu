sequence encoding | mã hóa chuỗi
masked language modeling (MLM) | mô hình hóa ngôn ngữ có che
next sentence prediction (NSP) | dự đoán câu tiếp theo
separator | ký hiệu phân tách
segment embedding | nhúng đoạn
sub-layer | tầng con
post-norm | chuẩn hóa sau
representation subspaces | không gian con biểu diễn
expressive power | năng lực biểu đạt
knowledge distillation | chưng cất tri thức
student model / teacher model | mô hình học trò / mô hình thầy
model compression / pruning / quantization | nén mô hình / tỉa / lượng tử hóa
dynamic network | mạng động
depth-adaptive / length-adaptive | thích ứng độ sâu / thích ứng độ dài
parameter sharing | chia sẻ tham số
multilingual / monolingual / bilingual | đa ngôn ngữ / đơn ngữ / song ngữ
cross-lingual transfer learning | học chuyển giao xuyên ngôn ngữ
cross-lingual language model (XLM) | mô hình ngôn ngữ xuyên ngôn ngữ
causal language modeling | mô hình hóa ngôn ngữ nhân quả
translation language modeling (TLM) | mô hình hóa ngôn ngữ dịch
language embedding | nhúng ngôn ngữ
language-agnostic | không phụ thuộc ngôn ngữ
code-switching | chuyển mã
low-/high-resource languages | ngôn ngữ ít/nhiều tài nguyên
curse of multilinguality / capacity interference | lời nguyền đa ngôn ngữ / giao thoa năng lực
prediction network / predictor | mạng dự đoán / bộ dự đoán
semantic equivalence | tương đương ngữ nghĩa
text entailment | kéo theo văn bản
grounded commonsense inference | suy luận thường thức có căn cứ
part-of-speech (POS) tagging | gán nhãn từ loại
BIO tagging scheme | lược đồ gán nhãn BIO
negative log-likelihood | log-hợp lý âm
dynamic programming / lattice | quy hoạch động / lưới
span / span prediction | đoạn / dự đoán đoạn
reading comprehension | đọc hiểu
adapter | bộ tiếp hợp (adapter)
catastrophic forgetting | quên thảm khốc
continual training / continual learning | huấn luyện liên tục / học liên tục
experience replay | phát lại kinh nghiệm
elastic weight consolidation | củng cố trọng số đàn hồi
foundation model | mô hình nền tảng
paradigm shift | chuyển dịch mô thức
