conversational agent | tác tử hội thoại
curse of dimensionality | lời nguyền số chiều
distributed representation | biểu diễn phân tán
representation learning | học biểu diễn
foundation model | mô hình nền tảng
autoregressive | tự hồi quy
decoder-only | chỉ có bộ giải mã
greedy decoding | giải mã tham lam
log-likelihood | log-hợp lý
token embedding | vectơ nhúng token
template | khuôn mẫu
placeholder | chỗ trống
binary classification | phân loại nhị phân
AI safety | an toàn AI
adversarial attack | tấn công đối kháng
agent | tác tử
ranking loss | hàm mất mát xếp hạng
forced decoding | giải mã cưỡng bức
uniform distribution | phân phối đều
regression | hồi quy
proximal policy optimization (PPO) | tối ưu chính sách cận kề (PPO)
arithmetic / commonsense reasoning | suy luận số học / suy luận thường thức
one-shot / few-shot / zero-shot CoT prompting | prompt CoT one-shot / few-shot / CoT zero-shot
