sub-layer | tầng con
encoding layer / decoding layer | tầng mã hóa / tầng giải mã
post-norm / pre-norm | post-norm (chuẩn hóa sau) / pre-norm (chuẩn hóa trước)
cross attention | chú ý chéo
encoder-only / decoder-only architecture | kiến trúc chỉ có bộ mã hóa / chỉ có bộ giải mã
absolute positional encoding | mã hóa vị trí tuyệt đối
attention weight | trọng số chú ý
scaled dot-product attention | chú ý tích vô hướng có co giãn
head (attention) | đầu
subspace | không gian con
identity mapping | ánh xạ đồng nhất
masking variable / additive mask / multiplicative mask | biến mặt nạ / mặt nạ cộng / mặt nạ nhân
warmup | khởi động
padding / zero padding | đệm / đệm không
cache | bộ nhớ đệm
syntax-aware | có nhận biết cú pháp
structural prior | tiên nghiệm cấu trúc
syntax tree / constituency parse tree / dependency parse tree | cây cú pháp / cây phân tích thành phần / cây phân tích phụ thuộc
tree linearization | tuyến tính hóa cây
part-of-speech (POS) | từ loại
branch / path | nhánh / đường
multi-scale | đa tỉ lệ
syntactic hierarchy | phân cấp cú pháp
upsampling / downsampling | tăng mẫu / giảm mẫu
feature map | bản đồ đặc trưng
probe / probing predictor / probing classifier | phép thăm dò / bộ dự đoán thăm dò / bộ phân loại thăm dò
attention map | bản đồ chú ý
emergent abilities | năng lực đột sinh
minimum-spanning tree | cây khung nhỏ nhất
edge probing | thăm dò cạnh
coreference resolution | phân giải đồng tham chiếu
morphology | hình thái học
function words | hư từ
masked language model | mô hình ngôn ngữ có mặt nạ
control task | tác vụ đối chứng
pooling | gộp
