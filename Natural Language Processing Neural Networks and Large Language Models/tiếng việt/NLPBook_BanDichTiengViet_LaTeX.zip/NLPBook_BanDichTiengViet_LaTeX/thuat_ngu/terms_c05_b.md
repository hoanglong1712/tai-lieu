hypothesis / partial hypothesis | giả thuyết / giả thuyết bộ phận
search space | không gian tìm kiếm
exhaustive search / exact search / approximate search | tìm kiếm vét cạn / tìm kiếm chính xác / tìm kiếm xấp xỉ
scoring function | hàm tính điểm
pruning (histogram / threshold) | cắt tỉa (theo biểu đồ tần suất / theo ngưỡng)
length bias / length reward / length normalization | thiên lệch độ dài / thưởng độ dài / chuẩn hóa độ dài
coverage / coverage vector / coverage score | độ phủ / vectơ độ phủ / điểm độ phủ
over-translation / under-translation | dịch thừa / dịch thiếu
statistical machine translation (SMT) | dịch máy thống kê
log-linear model | mô hình log-tuyến tính
minimum error rate training | huấn luyện cực tiểu tỉ lệ lỗi
non-autoregressive model/generation/decoding | mô hình/sinh/giải mã phi tự hồi quy
max-heap / priority queue | đống cực đại / hàng đợi ưu tiên
beam width / beam size | độ rộng chùm / kích thước chùm
greedy strategy | chiến lược tham lam
stopping criteria / early stopping | tiêu chí dừng / dừng sớm
search error / model error | lỗi tìm kiếm / lỗi mô hình
online search / simultaneous translation / wait-k | tìm kiếm trực tuyến / dịch song song / wait-k
prefix-to-prefix | tiền tố-sang-tiền tố
differentiable search / continuous optimization | tìm kiếm khả vi / tối ưu liên tục
one-hot representation / expected embedding / expected log-probability | biểu diễn one-hot / vectơ nhúng kỳ vọng / log xác suất kỳ vọng
simplex / constrained optimization | đơn hình / tối ưu có ràng buộc
diversity penalty / subspace method | hình phạt đa dạng / phương pháp không gian con
ensembling / system combination / prediction averaging | kết hợp mô hình / kết hợp hệ thống / lấy trung bình dự đoán
checkpoint ensembling / word lattice | kết hợp các điểm lưu / lưới từ
best-first search / A* search / value function | tìm kiếm tốt nhất trước / tìm kiếm A* / hàm giá trị
data augmentation / back-translation | tăng cường dữ liệu / dịch ngược
point-wise mutual information | thông tin tương hỗ theo điểm
maximum a posteriori (MAP) / minimum Bayes risk (MBR) | hậu nghiệm cực đại / rủi ro Bayes cực tiểu
risk function / evaluation metric | hàm rủi ro / độ đo đánh giá
