sentiment polarity | cực cảm xúc
emergent ability | năng lực đột sinh
downstream task | nhiệm vụ hạ nguồn
prompt template / template | khuôn mẫu prompt / khuôn mẫu
placeholder | chỗ trống
system prompt | prompt hệ thống
zero-shot / one-shot / few-shot learning | học zero-shot / one-shot / few-shot
Bayesian inference | suy luận Bayes
linear regression | hồi quy tuyến tính
meta-learning | học cách học
information retrieval (IR) | truy xuất thông tin
text classification | phân loại văn bản
sentiment analysis | phân tích cảm xúc
label mapping | ánh xạ nhãn
heuristics | quy tắc kinh nghiệm
cloze task | nhiệm vụ điền vào chỗ trống
information extraction | trích xuất thông tin
named entity / named entity recognition | thực thể có tên / nhận dạng thực thể có tên
relation extraction | trích xuất quan hệ
text completion | hoàn thành văn bản
text transformation | biến đổi văn bản
summarization | tóm tắt
text style transfer | chuyển đổi văn phong
question answering | hỏi đáp
calculation annotation | chú thích tính toán
coreference / anaphora | đồng tham chiếu / hồi chỉ
