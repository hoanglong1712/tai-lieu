morphological analysis | phân tích hình thái
analytic language | ngôn ngữ đơn lập
synthetic language | ngôn ngữ tổng hợp
inflection | biến tố
regular expression | biểu thức chính quy
normalization / canonicalization | chuẩn hóa / chính tắc hóa
lemma / lemmatization | từ nguyên dạng / đưa về nguyên dạng
stem / stemming | gốc từ / lấy gốc từ
suffix stripping | cắt hậu tố
part-of-speech (tagging) | từ loại (gán nhãn từ loại)
named entity recognition | nhận dạng thực thể có tên
length reward | phần thưởng độ dài
dynamic programming | quy hoạch động
pre-tokenizer | bộ tách token sơ bộ
Markov assumption | giả thiết Markov
hidden Markov model (HMM) | mô hình Markov ẩn (HMM)
conditional random fields (CRFs) | trường ngẫu nhiên có điều kiện (CRF)
morpheme | hình vị
Byte Pair Encoding (BPE) | mã hóa cặp byte (BPE)
symbol bigram | bigram ký hiệu
pointwise mutual information | thông tin tương hỗ theo điểm
information gain | độ lợi thông tin
likelihood | độ hợp lý
Expectation-Maximization (EM) | Kỳ vọng–Cực đại hóa (EM)
fractional count | số đếm phân số
one-hot representation | biểu diễn one-hot
distributed representation | biểu diễn phân tán
bag-of-words | túi từ
representation learning | học biểu diễn
lexical semantics | ngữ nghĩa học từ vựng
compositionality / principle of compositionality | tính kết hợp / nguyên lý kết hợp
contextuality | tính phụ thuộc ngữ cảnh
polysemous word | từ đa nghĩa
homonymy | đồng âm
lexeme | từ vị
word sense / word sense disambiguation (WSD) | nghĩa từ / khử nhập nhằng nghĩa từ (WSD)
collocation / idiom | cụm từ cố định / thành ngữ
