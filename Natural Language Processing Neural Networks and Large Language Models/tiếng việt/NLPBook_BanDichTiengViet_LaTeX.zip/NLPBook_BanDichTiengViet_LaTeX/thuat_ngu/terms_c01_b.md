ground-truth / gold-standard | nhãn đúng thực tế / chuẩn vàng
word clustering | phân cụm từ
unsupervised bilingual dictionary induction | quy nạp từ điển song ngữ không giám sát
parallel data | dữ liệu song song
isomorphism | đẳng cấu
semi-supervised learning | học bán giám sát
agent / environment / action | tác tử / môi trường / hành động
terminal state | trạng thái kết thúc
delayed reward (sparse reward) | phần thưởng trễ (phần thưởng thưa)
pretext task | bài toán tiền đề
downstream | hạ nguồn
inductive reasoning / inductive inference | suy luận quy nạp / suy diễn quy nạp
induction / deduction | quy nạp / diễn dịch
hypothesis space | không gian giả thuyết
curse of dimensionality | lời nguyền số chiều
generalize / generalization | tổng quát hóa
priors | tri thức tiên nghiệm / tiên nghiệm
model bias / algorithmic bias / sample bias | thiên kiến mô hình / thuật toán / mẫu
hypersphere | siêu cầu
feature mapping / kernel methods / kernel function / kernel trick | ánh xạ đặc trưng / phương pháp hạt nhân / hàm hạt nhân / thủ thuật hạt nhân
support vector machine (SVM) | máy vectơ hỗ trợ
expressive power | năng lực biểu diễn
non-parametric / parametric methods | phương pháp phi tham số / có tham số
k-nearest neighbors | k láng giềng gần nhất
Occam's Razor | dao cạo Occam
optimization | tối ưu hóa
cost function / empirical risk | hàm chi phí / rủi ro thực nghiệm
divergence (-based loss) | độ phân kỳ (mất mát dựa trên độ phân kỳ)
one-hot vector | vectơ one-hot
distance-based loss / curve fitting | mất mát dựa trên khoảng cách / khớp đường cong
regression / multivariate regression | hồi quy / hồi quy đa biến
quality estimation | ước lượng chất lượng
mean squared error (MSE) / mean absolute error (MAE) | sai số bình phương trung bình / sai số tuyệt đối trung bình
margin / margin-based loss / large-margin training | lề / mất mát dựa trên lề / huấn luyện lề lớn
hinge loss | mất mát bản lề
ranking loss / pairwise / pointwise / listwise / learning-to-rank | mất mát xếp hạng / theo cặp / theo từng điểm / theo danh sách / học xếp hạng
information retrieval / metric learning | truy xuất thông tin / học độ đo
contrastive loss / contrastive learning | mất mát tương phản / học tương phản
augmented | (phiên bản) tăng cường
error-based loss | mất mát dựa trên lỗi
expected loss / expected risk / Bayesian risk | mất mát kỳ vọng / rủi ro kỳ vọng / rủi ro Bayes
quadratic programming | quy hoạch toàn phương
minimum error-rate training (MERT) | huấn luyện tỉ lệ lỗi tối thiểu (MERT)
capacity | năng lực (mô hình)
held-out validation set / early stopping | tập kiểm định giữ lại / dừng sớm
ensembling / component models | kết hợp (mô hình) / mô hình thành phần
dependent / independent variable | biến phụ thuộc / biến độc lập
syntactic parser | bộ phân tích cú pháp
model errors / search errors | lỗi mô hình / lỗi tìm kiếm
