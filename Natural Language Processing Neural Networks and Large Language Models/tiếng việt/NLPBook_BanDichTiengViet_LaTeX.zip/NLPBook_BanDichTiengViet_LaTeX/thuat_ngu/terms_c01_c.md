model selection / model evaluation | lựa chọn mô hình / đánh giá mô hình
gold-standard | đáp án chuẩn
training error / test error / generalization error | lỗi huấn luyện / lỗi kiểm tra / lỗi tổng quát hóa
learning curves | đường cong học
i.i.d. assumption | giả định i.i.d. (độc lập và cùng phân phối)
No Free Lunch Theorem | Định lý Không có bữa trưa miễn phí
model complexity / model capacity | độ phức tạp của mô hình / năng lực của mô hình
VC dimension | chiều VC
hypothesis space | không gian giả thuyết
Occam's Razor | dao cạo Occam
effective degrees of freedom | số bậc tự do hiệu dụng
shatter | tách trọn vẹn
Minimum Description Length (MDL) | độ dài mô tả tối thiểu
AIC / BIC / MML | tiêu chuẩn thông tin Akaike / tiêu chuẩn thông tin Bayes / độ dài thông điệp tối thiểu
bias (statistical) / variance | độ chệch / phương sai  (khác "độ lệch (bias)" của trọng số)
bias-variance tradeoff / decomposition | sự đánh đổi / phân rã độ chệch--phương sai
systematic error | sai số hệ thống
mean squared error | sai số bình phương trung bình
ensemble learning / base learners / model averaging / soft voting | học kết hợp / bộ học cơ sở / lấy trung bình mô hình / bỏ phiếu mềm
mixture of experts | hỗn hợp chuyên gia
early stopping | dừng sớm
sampling bias | sai lệch lấy mẫu
cross-validation / k-fold | kiểm định chéo / kiểm định chéo k-phần
sample efficiency | hiệu quả mẫu
performance measure | thước đo hiệu năng
precision / recall / F1 | độ chính xác dự đoán / độ phủ / điểm F1
brevity penalty | hình phạt độ ngắn
significance test / significance level / p-value | kiểm định ý nghĩa thống kê / mức ý nghĩa / giá trị p
null / alternative hypothesis | giả thuyết không / giả thuyết đối
Type I / Type II error | sai lầm loại I / loại II
parametric / non-parametric test | kiểm định tham số / phi tham số
part-of-speech tagging / chunking | gán nhãn từ loại / phân đoạn cụm
named entity recognition (NER) | nhận dạng thực thể có tên
auto-regressive / auto-encoding | tự hồi quy / tự mã hóa
downstream task | nhiệm vụ hạ nguồn
syntactic parser / parse tree / statistical parsing | bộ phân tích cú pháp / cây phân tích cú pháp / phân tích cú pháp thống kê
context-free grammar (CFG) | văn phạm phi ngữ cảnh
relevance / similarity learning / metric learning | mức độ liên quan / học độ tương đồng / học độ đo
contrastive loss | hàm mất mát tương phản
linguistic alignment / word alignment | gióng hàng ngôn ngữ / gióng hàng từ
soft word alignment matrix | ma trận gióng hàng từ mềm
bilingual dictionary induction | quy nạp từ điển song ngữ
information extraction / span prediction | trích xuất thông tin / dự đoán đoạn
coreference resolution / template filling | phân giải đồng tham chiếu / điền mẫu
regular expressions | biểu thức chính quy
