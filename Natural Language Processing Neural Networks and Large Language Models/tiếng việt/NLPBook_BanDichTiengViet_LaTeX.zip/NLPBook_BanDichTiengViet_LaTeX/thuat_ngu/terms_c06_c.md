latency | độ trễ
scalability | khả năng mở rộng
memory footprint | lượng bộ nhớ chiếm dụng
sparse attention | chú ý thưa
sparsification / sparse matrix / sparsity ratio | làm thưa / ma trận thưa / tỷ lệ thưa
attention matrix / attention map | ma trận chú ý / bản đồ chú ý
attention field | trường chú ý
span-based / local attention | chú ý dựa trên khoảng / chú ý cục bộ
chunked attention | chú ý theo khối
strided attention | chú ý theo bước trượt
dilated context window | cửa sổ ngữ cảnh giãn
global / random attention | chú ý toàn cục / chú ý ngẫu nhiên
throughput | thông lượng
memory bank | kho bộ nhớ
non-parametric model | mô hình phi tham số
cache | bộ đệm
pooling / average pooling | gộp / gộp trung bình
chunk-level representation | biểu diễn mức khối
priority queue | hàng đợi ưu tiên
continuous memory | bộ nhớ liên tục
function approximation / basis function | xấp xỉ hàm / hàm cơ sở
vector database | cơ sở dữ liệu vectơ
similarity search | tìm kiếm tương tự
receptive field | trường tiếp nhận
dimensionality reduction | giảm chiều
low-rank matrix | ma trận hạng thấp
kernel methods / kernel trick / kernel function | phương pháp hạt nhân / thủ thuật hạt nhân / hàm hạt nhân
inner product | tích trong
diagonal matrix | ma trận đường chéo
kernelized attention model | mô hình chú ý hạt nhân hóa
linear attention model | mô hình chú ý tuyến tính
feature map | ánh xạ đặc trưng
sub-space model | mô hình không gian con
Cartesian product / product key | tích Descartes / khóa tích
redundancy / over-parameterized | dư thừa / thừa tham số
prune | tỉa
embedding sharing / layer-wise sharing | chia sẻ vectơ nhúng / chia sẻ theo tầng
multi-query attention / grouped-query attention | chú ý đa truy vấn / chú ý truy vấn theo nhóm
memory bandwidth | băng thông bộ nhớ
reversible residual network | mạng phần dư khả nghịch
