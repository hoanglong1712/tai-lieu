local attention | chú ý cục bộ
global attention | chú ý toàn cục
penalty term | số hạng phạt
soft / hard constraint | ràng buộc mềm / ràng buộc cứng
sparse attention models | mô hình chú ý thưa
relative positional embedding / representation (RPR) | nhúng vị trí tương đối / biểu diễn vị trí tương đối (RPR)
gating network / gating model | mạng cổng / mô hình cổng
routing model | mô hình định tuyến
multiplicative mask | mặt nạ nhân
post-norm / pre-norm | chuẩn hóa sau (post-norm) / chuẩn hóa trước (pre-norm)
identity mapping | ánh xạ đồng nhất
vanishing / exploding gradient | tiêu biến gradient / bùng nổ gradient
learning rate warmup | khởi động tốc độ học
parameter initialization | khởi tạo tham số
Xavier initialization | khởi tạo Xavier
Lipschitz constant | hằng số Lipschitz
model growth / depth growth | tăng trưởng mô hình / tăng trưởng độ sâu
shallow-to-deep training | huấn luyện từ nông đến sâu
layer fusion | hợp nhất tầng
densely connected network | mạng kết nối dày đặc
average pooling | gộp trung bình
sub-layer dropout / layer dropout | dropout tầng con / dropout tầng
co-adaptation | đồng thích nghi
ensemble / ensemble learning | tập hợp mô hình / học tập hợp
ordinary differential equation (ODE) | phương trình vi phân thường (ODE)
Euler discretization / Euler method | rời rạc hóa Euler / phương pháp Euler
linear multi-step method | phương pháp đa bước tuyến tính
local truncation error | sai số chặt cụt địa phương
neural ODE | ODE nơ-ron
mixture-of-experts (MoE) | hỗn hợp chuyên gia (MoE)
divide-and-conquer | chia để trị
training instability | bất ổn định khi huấn luyện
checkpoint | điểm lưu (checkpoint)
mixed precision | độ chính xác hỗn hợp
