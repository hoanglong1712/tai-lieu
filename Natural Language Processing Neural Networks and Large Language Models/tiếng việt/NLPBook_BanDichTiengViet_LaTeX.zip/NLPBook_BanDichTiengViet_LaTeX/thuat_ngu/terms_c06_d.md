receptive field | trường tiếp nhận
depthwise CNN | CNN theo chiều sâu
linear attention | chú ý tuyến tính
feature map | ánh xạ đặc trưng
moving average | trung bình trượt
state-space model (SSM) | mô hình không gian trạng thái
state variable | biến trạng thái
state equation / output equation | phương trình trạng thái / phương trình đầu ra
bilinear transform | biến đổi song tuyến tính
Zero-Order-Hold (ZOH) | giữ bậc không
diagonalization | chéo hóa
diagonal state-space model | mô hình không gian trạng thái đường chéo
conditional computation | tính toán có điều kiện
Neural Architecture Search (NAS) | tìm kiếm kiến trúc mạng nơ-ron
automated machine learning (AutoML) | học máy tự động
dynamic neural networks | mạng nơ-ron động
early exiting | thoát sớm
early exit classifier | bộ phân loại thoát sớm
sparse expert model | mô hình chuyên gia thưa
sentence-level / token-level depth-adaptive model | mô hình thích nghi độ sâu mức câu / mức token
transfer learning | học chuyển giao
knowledge distillation | chưng cất tri thức
teacher-student training | huấn luyện thầy--trò
data augmentation | tăng cường dữ liệu
unstructured / structured pruning | cắt tỉa phi cấu trúc / có cấu trúc
token pruning | cắt tỉa token
cross-attention | chú ý chéo
downsampling / progressive downsampling | giảm mẫu / giảm mẫu lũy tiến
strided convolution | tích chập có bước nhảy
quantization / post-training quantization | lượng tử hóa / lượng tử hóa sau huấn luyện
kernel fusion | hợp nhất nhân
connectionist temporal classification (CTC) | phân loại thời gian kết nối
speech encoder / text encoder / shared encoder | bộ mã hóa tiếng nói / văn bản / dùng chung
patch | mảnh (ảnh)
visual question answering (VQA) | hỏi đáp thị giác
sentence embedding | vectơ nhúng câu
emergence | trồi sinh
speculative decoding | giải mã suy đoán
foundation model | mô hình nền tảng
