reasoning (Chương 12) | lập luận
inference-time scaling | co giãn lúc suy luận
post-training | hậu huấn luyện
trajectory | quỹ đạo
CoT trace / reasoning trace | vết CoT / vết lập luận
chat template | khuôn mẫu hội thoại
process reward model (PRM) | mô hình phần thưởng quá trình (PRM)
process supervision / outcome supervision | giám sát quá trình / giám sát kết quả
credit assignment problem | bài toán phân bổ công trạng
rollout | triển khai
sparse / dense reward | phần thưởng thưa / dày
reward shaping | định hình phần thưởng
telescoping sum | tổng rút gọn kiểu ống lồng
future return | lợi tức tương lai
advantage function | hàm ưu thế
temporal difference error | sai số chênh lệch thời gian
value baseline / value network | giá trị cơ sở / mạng giá trị
actor-critic | tác nhân--phê bình
discount factor | hệ số chiết khấu
group relative policy optimization (GRPO) | tối ưu chính sách tương đối theo nhóm (GRPO)
on-policy / off-policy distillation | chưng cất on-policy / off-policy
knowledge distillation / self-distillation | chưng cất tri thức / tự chưng cất
exposure bias / distribution shift | thiên lệch phơi nhiễm / dịch chuyển phân phối
KL divergence | độ phân kỳ KL
aha moment | khoảnh khắc "à há"
synthetic data generation | sinh dữ liệu tổng hợp
agent / agentic reasoning | tác tử / lập luận kiểu tác tử
outcome-/process-based evaluation | đánh giá dựa trên kết quả / quá trình
false positive | dương tính giả
meta-reasoning | siêu lập luận
majority voting | bỏ phiếu đa số
win rate | tỉ lệ thắng
data contamination | nhiễm bẩn dữ liệu
robustness | độ vững
unfaithful | không trung thực
reward hacking | lách phần thưởng
benchmark saturation | bão hòa bộ đánh giá chuẩn
mechanistic interpretability | khả năng diễn giải cơ chế
residual stream | dòng residual
latent / implicit reasoning | lập luận tiềm ẩn / lập luận ngầm
pause token | token tạm dừng
chain of continuous thought (COCONUT) | chuỗi suy nghĩ liên tục (COCONUT)
memorization | ghi nhớ
stochastic parrots | con vẹt ngẫu nhiên
formal / functional linguistic competence | năng lực ngôn ngữ hình thức / chức năng
tool-augmented reasoning | lập luận tăng cường công cụ
