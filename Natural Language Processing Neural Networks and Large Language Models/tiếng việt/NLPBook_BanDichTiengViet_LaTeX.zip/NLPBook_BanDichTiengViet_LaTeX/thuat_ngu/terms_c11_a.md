inference (in Ch. 11) | suy luận (reasoning = lập luận)
inference-time scaling | co giãn tại thời điểm suy luận
prefill-decode / prefilling | điền trước--giải mã / điền trước
key-value cache | bộ nhớ đệm khóa--giá trị
autoregressive | tự hồi quy
mask | mặt nạ
compute-bound / memory-bound | bị giới hạn bởi tính toán / bị giới hạn bởi bộ nhớ
sparse attention | chú ý thưa
exhaustive search / heuristic search | tìm kiếm vét cạn / tìm kiếm heuristic
exploration / exploitation | khám phá / khai thác
hypothesis | giả thuyết
search space | không gian tìm kiếm
prune | tỉa
Cartesian product | tích Descartes
greedy decoding | giải mã tham lam
beam width | độ rộng chùm
deterministic | tất định
top-k / top-p sampling, nucleus sampling | lấy mẫu top-k / top-p, lấy mẫu hạt nhân
selection pool | tập chọn
renormalize | chuẩn hóa lại
logit | logit
long tail | đuôi dài
degenerate output | đầu ra suy biến
temperature | nhiệt độ
maximum a posteriori (MAP) / minimum Bayes risk (MBR) | cực đại hậu nghiệm / rủi ro Bayes tối thiểu
penalty term / repetition / length / diversity / constraint-based penalty | số hạng phạt / phạt lặp lại / độ dài / đa dạng / dựa trên ràng buộc
likelihood | độ hợp lý
speculative decoding / speculative execution | giải mã suy đoán / thực thi suy đoán
draft model / verification model | mô hình nháp / mô hình kiểm chứng
uniform distribution | phân phối đều
stopping criteria | tiêu chí dừng
robustness | độ bền vững
perplexity | độ hỗn loạn
out-of-distribution | ngoài phân phối
request latency / throughput / TTFT / ITL / resource utilization | độ trễ yêu cầu / thông lượng / thời gian đến token đầu tiên / độ trễ giữa các token / mức sử dụng tài nguyên
