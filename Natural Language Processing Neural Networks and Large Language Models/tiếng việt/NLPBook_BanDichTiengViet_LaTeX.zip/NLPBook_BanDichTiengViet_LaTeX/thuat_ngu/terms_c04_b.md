kernel | nhân
filter | bộ lọc
feature map | bản đồ đặc trưng
receptive field | trường tiếp nhận
convolution / convolution operation | tích chập / phép tích chập
stride | bước trượt
padding / zero-padding | phần đệm / đệm số 0
downsample | giảm mẫu
cross-correlation | tương quan chéo
convolutional layer | tầng tích chập
pooling layer / max-pooling / average-pooling | tầng gộp / gộp cực đại / gộp trung bình
translation invariance | tính bất biến đối với phép tịnh tiến
long-distance dependencies | phụ thuộc khoảng cách xa
concatenation | ghép nối
lookup table | bảng tra
absolute / relative positional encoding | mã hóa vị trí tuyệt đối / tương đối
text classification | phân loại văn bản
transcription / transcription units / labels | bản phiên âm / đơn vị phiên âm / nhãn phiên âm
frames | khung
connectionist temporal classification (CTC) | phân loại thời gian kết nối (CTC)
Viterbi decoding | giải mã Viterbi
dynamic programming | quy hoạch động
graphical models / undirected graphical models | mô hình đồ thị / mô hình đồ thị vô hướng
hidden Markov models (HMM) | mô hình Markov ẩn (HMM)
transition / emission probability | xác suất chuyển / xác suất phát xạ
conditional random fields (CRF) / linear-chain CRF | trường ngẫu nhiên có điều kiện (CRF) / CRF chuỗi tuyến tính
feature functions | hàm đặc trưng
forward-backward | tiến–lùi
Markov chain | xích Markov
Gaussian mixture models (GMM) | mô hình hỗn hợp Gauss (GMM)
end-to-end | đầu-cuối
compositional models | mô hình kết hợp
bag-of-words | túi từ
text embedding / sentence embedding | nhúng văn bản / nhúng câu
