instruction alignment | căn chỉnh theo chỉ dẫn
human preference alignment | căn chỉnh theo sở thích của con người
instruction following | khả năng làm theo chỉ dẫn
single-round / multi-round prediction | dự đoán một lượt / nhiều lượt
pruning | cắt tỉa
quantization | lượng tử hóa
parameter-efficient fine-tuning | tinh chỉnh hiệu quả tham số
soft prompts | prompt mềm
post-training | hậu huấn luyện
catastrophic forgetting | hiện tượng quên thảm khốc
early stopping | dừng sớm
crowdsourcing | huy động cộng đồng
open-domain QA | hỏi đáp miền mở
robustness | độ bền vững
data augmentation | tăng cường dữ liệu
self-instruct | tự tạo chỉ dẫn
input inversion | đảo ngược đầu vào
evolutionary algorithms | thuật toán tiến hóa
superficial alignment hypothesis | giả thuyết căn chỉnh bề mặt
sample efficiency | hiệu quả mẫu
generalization | tổng quát hóa
out-of-distribution generalization | tổng quát hóa ngoài phân phối
weak-to-strong generalization | tổng quát hóa từ yếu đến mạnh
knowledge distillation | chưng cất tri thức
performance gap recovered (PGR) | tỉ lệ khoảng cách hiệu năng được thu hồi (PGR)
interpolation coefficient | hệ số nội suy
ensemble learning | học kết hợp
majority voting | bỏ phiếu đa số
weighted averaging | trung bình có trọng số
stacking | xếp chồng
model cascading | phân tầng mô hình
