distributional hypothesis | giả thuyết phân bố
distributional representation | biểu diễn phân bố
distributed representation | biểu diễn phân tán
distributional semantics | ngữ nghĩa học phân bố
co-occurrence matrix | ma trận đồng xuất hiện
bag-of-words | túi từ
pointwise mutual information (PMI) | thông tin tương hỗ theo điểm
correlation coefficient | hệ số tương quan
term frequency (TF) | tần suất từ
inverse document frequency (IDF) | nghịch đảo tần suất văn bản
information retrieval | truy xuất thông tin
latent semantic analysis (LSA) | phân tích ngữ nghĩa tiềm ẩn
singular value decomposition (SVD) | phân tích giá trị suy biến
singular value / left-/right-singular vector | giá trị suy biến / vectơ suy biến trái/phải
semi-unitary / semi-orthogonal | nửa unita / nửa trực giao
low-rank approximation | xấp xỉ hạng thấp
principal component analysis (PCA) | phân tích thành phần chính
dimensionality reduction | giảm chiều
covariance matrix | ma trận hiệp phương sai
eigenvector / eigenvalue | vectơ riêng / giá trị riêng
Lagrange multiplier | nhân tử Lagrange
latent Dirichlet allocation (LDA) | phân bổ Dirichlet tiềm ẩn
factor analysis | phân tích nhân tố
independent component analysis (ICA) | phân tích thành phần độc lập
background task | bài toán nền
embedding layer / word embedding table | tầng nhúng / bảng nhúng từ
downstream task | bài toán hạ nguồn
log-linear | log-tuyến tính
homomorphism | đồng cấu
curse of dimensionality | lời nguyền số chiều
feature engineering | kỹ nghệ đặc trưng
shallow model | mô hình nông
extrinsic / intrinsic evaluation | đánh giá ngoại tại / nội tại
cosine similarity | độ tương tự cosin
semantic relatedness / similarity | độ liên quan / độ tương tự ngữ nghĩa
polysemy | đa nghĩa
word analogy | loại suy từ
linguistic regularities | quy luật ngôn ngữ
priming / prime word / target word | mồi / từ mồi / từ đích
self-paced reading | đọc tự điều chỉnh nhịp
t-SNE | nhúng láng giềng ngẫu nhiên phân phối t
contextualized representation | biểu diễn theo ngữ cảnh
vector space model | mô hình không gian vectơ
