automated prompting | prompting tự động
automatic prompt design / prompt optimization | thiết kế prompt tự động / tối ưu hóa prompt
automated machine learning (AutoML) | học máy tự động (AutoML)
neural architecture search (NAS) | tìm kiếm kiến trúc nơ-ron (NAS)
seed prompt | prompt hạt giống
candidate pool | tập ứng viên
metric | độ đo
log-likelihood / negative log-likelihood | log-hợp lý / log-hợp lý âm
paraphrasing | diễn đạt lại
self-refinement | tự tinh chỉnh
evolutionary computation | tính toán tiến hóa
prompt generator | bộ sinh prompt
adaptor / adaptor layer | bộ thích nghi / tầng thích nghi
policy network | mạng chính sách
hard prompt / soft prompt | prompt cứng / prompt mềm
distributed representation | biểu diễn phân tán
hidden space | không gian ẩn
context distillation / knowledge distillation | chưng cất ngữ cảnh / chưng cất tri thức
teacher model / student model | mô hình thầy / mô hình trò
sequence-level loss | mất mát mức chuỗi
KL divergence | độ phân kỳ KL
full fine-tuning | tinh chỉnh toàn bộ
parameter-efficient fine-tuning | tinh chỉnh hiệu quả tham số
prefix fine-tuning / prefix | tinh chỉnh tiền tố / tiền tố
prompt tuning | tinh chỉnh prompt
pseudo embedding / pseudo token | vectơ nhúng giả / token giả
prompt embedding | vectơ nhúng prompt
summary token | token tóm tắt
text simplification | đơn giản hóa văn bản
foundation model | mô hình nền tảng
