norm (l_p, l_1, l_2) | chuẩn
regularization term | số hạng chính quy hóa
Lasso / Ridge regularization | chính quy hóa Lasso / Ridge
sparse / sparsity penalty | thưa / hàm phạt thưa
feature selection | chọn lọc đặc trưng
weight decay | suy giảm trọng số
prior knowledge / prior | tri thức tiên nghiệm / phân phối tiên nghiệm
co-adaptation | đồng thích nghi
dropout rate | tỉ lệ dropout
mask vector | vectơ mặt nạ
ensemble | tổ hợp mô hình
early stopping | dừng sớm
model selection | lựa chọn mô hình
bias-variance trade-off | sự đánh đổi độ chệch--phương sai
checkpoint | điểm lưu
shrinkage estimator | bộ ước lượng co
multinomial distribution | phân phối đa thức
temperature scaling | co giãn nhiệt độ
Boltzmann distribution | phân phối Boltzmann
label smoothing | làm trơn nhãn
ground-truth | chuẩn đúng
posterior (probability) | (xác suất) hậu nghiệm
minimum Bayesian risk | rủi ro Bayes cực tiểu
robust statistics | thống kê vững
outliers | điểm ngoại lai
noise injection | tiêm nhiễu
Gaussian noise | nhiễu Gauss
data augmentation | tăng cường dữ liệu
back-translation | dịch ngược
latent space / latent variable | không gian ẩn / biến ẩn
adversarial machine learning / adversarial samples / attacks | học máy đối kháng / mẫu đối kháng / cuộc tấn công
data clustering | phân cụm dữ liệu
association rule mining | khai phá luật kết hợp
representation learning / feature learning | học biểu diễn / học đặc trưng
principal component analysis (PCA) | phân tích thành phần chính
dimensionality reduction | giảm chiều
code | mã
reconstruction loss | mất mát tái tạo
bottleneck | nút thắt cổ chai
undercomplete auto-encoder | bộ tự mã hóa thiếu đủ
feature extractor | bộ trích xuất đặc trưng
downstream task | tác vụ hạ nguồn
sparse auto-encoder / sparse coding | bộ tự mã hóa thưa / mã hóa thưa
KL divergence | độ phân kỳ KL
contractive auto-encoder (CAE) | bộ tự mã hóa co
Jacobian matrix | ma trận Jacobi
Frobenius norm | chuẩn Frobenius
contraction mapping | ánh xạ co
denoising auto-encoder (DAE) | bộ tự mã hóa khử nhiễu
corruption / corrupted input | làm hỏng / đầu vào bị làm hỏng
masking noise / salt-and-pepper noise / impulse noise | nhiễu che / nhiễu muối tiêu / nhiễu xung
variational auto-encoder (VAE) | bộ tự mã hóa biến phân
intractable | không tính được
marginal distribution / marginal likelihood | phân phối biên / hàm hợp lý biên
evidence lower bound (ELBO) | cận dưới bằng chứng
reparameterization trick | mẹo tái tham số hóa
point estimate | ước lượng điểm
