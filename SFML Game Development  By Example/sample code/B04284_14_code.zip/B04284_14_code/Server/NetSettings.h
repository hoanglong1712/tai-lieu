#pragma once
// SERVER
#define SNAPSHOT_INTERVAL 100