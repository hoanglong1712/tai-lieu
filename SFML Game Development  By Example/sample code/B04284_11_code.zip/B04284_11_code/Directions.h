#pragma once
enum class Direction{ Up = 0, Left, Down, Right };